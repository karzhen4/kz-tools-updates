فۆنتی IBM Plex Sans Arabic:
- ئەگەر ئینتەرنێت هەبێت، پانێڵەکە خۆی لە Google Fonts دایدەبەزێنێت.
- بۆ بێ-ئینتەرنێت، ئەم فایلانە لێرە دابنێ (لە fonts.google.com/specimen/IBM+Plex+Sans+Arabic):
  IBMPlexSansArabic-Regular.ttf  (یان .woff2)
  IBMPlexSansArabic-Medium.ttf
  IBMPlexSansArabic-SemiBold.ttf
  IBMPlexSansArabic-Bold.ttf
- ئەگەر فۆنتەکە لەسەر سیستەمەکەت دامەزراوە، ئەویش بەکاردێت.
