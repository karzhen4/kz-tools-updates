/* KZ Tools — دروستکردنی لاوەر سێرد بە Canvas (PNG ی شەفاف 1920x1080) */
(function () {
  'use strict';
  var KZ = window.KZ, fs = require('fs'), path = require('path');
  var W = 1920, H = 1080, FONT = '"IBM Plex Sans Arabic","KZPlex","Geeza Pro","Segoe UI",Tahoma,sans-serif';
  var LW = KZ.lower = {};

  function rr(c, x, y, w, h, r) {
    c.beginPath(); c.moveTo(x + r, y); c.lineTo(x + w - r, y); c.quadraticCurveTo(x + w, y, x + w, y + r);
    c.lineTo(x + w, y + h - r); c.quadraticCurveTo(x + w, y + h, x + w - r, y + h); c.lineTo(x + r, y + h);
    c.quadraticCurveTo(x, y + h, x, y + h - r); c.lineTo(x, y + r); c.quadraticCurveTo(x, y, x + r, y); c.closePath();
  }
  function wrap(c, text, maxW) {
    var words = String(text).split(/\s+/), lines = [], cur = '', i, t;
    for (i = 0; i < words.length; i++) {
      t = cur ? cur + ' ' + words[i] : words[i];
      if (cur && c.measureText(t).width > maxW) { lines.push(cur); cur = words[i]; } else cur = t;
    }
    if (cur) lines.push(cur);
    return lines;
  }
  function theme(o) {
    if (o.theme === 'light') return { bg: 'rgba(255,255,255,0.96)', t1: '#0a1a14', t2: '#3a5a4b', stripe: o.accent };
    if (o.theme === 'accent') return { bg: o.accent, t1: '#0a1a14', t2: 'rgba(10,26,20,0.75)', stripe: '#0a1a14' };
    return { bg: 'rgba(10,26,20,0.93)', t1: '#ffffff', t2: '#b9f3d6', stripe: o.accent };
  }

  LW.draw = function (canvas, o) {
    canvas.width = W; canvas.height = H;
    var c = canvas.getContext('2d'), th = theme(o);
    c.clearRect(0, 0, W, H);
    c.direction = 'rtl'; c.textBaseline = 'alphabetic';
    var left = o.side === 'left';

    if (o.style === 'tag') {
      c.font = '700 40px ' + FONT;
      var tw = c.measureText(o.line1 || ' ').width, bw = tw + 90, bh = 84, bx = left ? 80 : W - 80 - bw, by = 70;
      c.fillStyle = o.accent; rr(c, bx, by, bw, bh, 18); c.fill();
      c.fillStyle = '#0a1a14'; c.textAlign = 'center'; c.fillText(o.line1 || '', bx + bw / 2, by + 56);
      return;
    }

    if (o.style === 'headline') {
      var x0 = 80, bw2 = W - 160, pad = 50, stripeW = 26;
      c.font = '700 56px ' + FONT;
      var ls = wrap(c, o.line1 || '', bw2 - stripeW - pad * 2).slice(0, 2), lh = 78, bh2 = ls.length * lh + 56, by2 = 940 - bh2;
      c.fillStyle = th.bg; rr(c, x0, by2, bw2, bh2, 18); c.fill();
      c.fillStyle = th.stripe; rr(c, x0 + bw2 - stripeW, by2, stripeW, bh2, 18); c.fill();
      c.fillRect(x0 + bw2 - stripeW, by2, 14, bh2);
      c.fillStyle = th.t1; c.textAlign = 'right';
      ls.forEach(function (l, i) { c.fillText(l, x0 + bw2 - stripeW - pad, by2 + 28 + 56 + i * lh - 6); });
      return;
    }

    // lower (ناو + ناونیشان)
    var pw = 1100, ph = o.line2 ? 190 : 130, px = left ? 80 : W - 80 - pw, py = 940 - ph, sw = 18;
    c.fillStyle = th.bg; rr(c, px, py, pw, ph, 20); c.fill();
    c.fillStyle = th.stripe;
    if (left) { rr(c, px, py, sw + 6, ph, 20); c.fill(); c.fillRect(px + 8, py, sw - 2, ph); }
    else { rr(c, px + pw - sw - 6, py, sw + 6, ph, 20); c.fill(); c.fillRect(px + pw - sw - 6, py, sw - 2, ph); }
    var tr = left ? px + pw - 50 : px + pw - sw - 50;
    c.textAlign = 'right';
    c.fillStyle = th.t1; c.font = '700 62px ' + FONT;
    c.fillText(o.line1 || '', tr, py + (o.line2 ? 82 : 86));
    if (o.line2) { c.fillStyle = th.t2; c.font = '400 38px ' + FONT; c.fillText(o.line2, tr, py + 148); }
  };

  LW.options = function () {
    return {
      style: KZ.$('#lt-style .on').getAttribute('data-v'), line1: KZ.$('#lt-l1').value, line2: KZ.$('#lt-l2').value,
      theme: KZ.$('#lt-theme').value, accent: KZ.$('#lt-accent').value, side: KZ.$('#lt-side').value
    };
  };
  LW.preview = function () {
    var cv = KZ.$('#lt-prev'); if (!cv) return;
    var go = function () { LW.draw(cv, LW.options()); };
    try { document.fonts.load('700 40px "IBM Plex Sans Arabic"').then(go, go); } catch (e) { go(); }
    go();
  };
  LW.save = function () {
    var cv = document.createElement('canvas'); LW.draw(cv, LW.options());
    var b64 = cv.toDataURL('image/png').replace(/^data:image\/png;base64,/, '');
    var p = path.join(KZ.workDir(), 'lower_' + Date.now() + '.png');
    fs.writeFileSync(p, Buffer.from(b64, 'base64'));
    return p;
  };
})();
