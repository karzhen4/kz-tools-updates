/* KZ Tools — ئەنیمەیشنی کانڤاس (ژمێرەر، نووسین، چارت) و ناوچەی سەلامەت. دەرچوو: ProRes 4444 بە ئەلفا */
(function () {
  'use strict';
  var KZ = window.KZ, L2 = window.KZ_LIB2, fs = require('fs'), path = require('path');
  var FONT = '"IBM Plex Sans Arabic","KZPlex","Geeza Pro","Segoe UI",Tahoma,sans-serif';
  var A = KZ.anim = {}, E = L2.ease;

  function cl(x) { return x < 0 ? 0 : x > 1 ? 1 : x; }
  function rr(c, x, y, w, h, r) {
    c.beginPath(); c.moveTo(x + r, y); c.lineTo(x + w - r, y); c.quadraticCurveTo(x + w, y, x + w, y + r);
    c.lineTo(x + w, y + h - r); c.quadraticCurveTo(x + w, y + h, x + w - r, y + h); c.lineTo(x + r, y + h);
    c.quadraticCurveTo(x, y + h, x, y + h - r); c.lineTo(x, y + r); c.quadraticCurveTo(x, y, x + r, y); c.closePath();
  }
  function theme(o) {
    if (o.theme === 'light') return { bg: 'rgba(255,255,255,0.96)', t1: '#0a1a14', t2: '#3a5a4b', stripe: o.accent };
    if (o.theme === 'accent') return { bg: o.accent, t1: '#0a1a14', t2: 'rgba(10,26,20,0.75)', stripe: '#0a1a14' };
    return { bg: 'rgba(10,26,20,0.93)', t1: '#ffffff', t2: '#b9f3d6', stripe: o.accent };
  }
  function env(t, dur) { return Math.min(cl(t / 0.3), cl((dur - t) / 0.3)); }   // دەرکەوتن و نەمان

  // ---------- ژمێرەر ----------
  function drawCounter(c, t, o, W, H) {
    var th = theme(o), animT = Math.max(0.5, o.dur * 0.65), v = o.from + (o.to - o.from) * E.outCubic(cl(t / animT));
    var txt = (o.prefix || '') + L2.formatNumber(v, { decimals: o.decimals, digits: o.digits }) + (o.suffix || '');
    var big = Math.round(H * 0.13), cy = o.pos === 'bottom' ? H * 0.74 : H * 0.5;
    c.direction = 'rtl'; c.textAlign = 'center';
    c.font = '700 ' + big + 'px ' + FONT; var w1 = c.measureText(txt).width;
    c.font = '500 ' + Math.round(big * 0.38) + 'px ' + FONT; var w2 = o.label ? c.measureText(o.label).width : 0;
    var bw = Math.max(w1, w2) + big * 1.3, bh = o.label ? big * 2.1 : big * 1.55;
    var lift = (1 - E.outCubic(cl(t / 0.45))) * 36, x = (W - bw) / 2, y = cy - bh / 2 + lift;
    c.globalAlpha = env(t, o.dur);
    c.fillStyle = th.bg; rr(c, x, y, bw, bh, big * 0.22); c.fill();
    c.fillStyle = th.stripe; rr(c, x + bw - big * 0.16, y, big * 0.16, bh, big * 0.08); c.fill();
    c.fillStyle = th.t1; c.font = '700 ' + big + 'px ' + FONT; c.fillText(txt, W / 2 - big * 0.04, y + (o.label ? big * 1.02 : bh / 2 + big * 0.34));
    if (o.label) { c.fillStyle = th.t2; c.font = '500 ' + Math.round(big * 0.38) + 'px ' + FONT; c.fillText(o.label, W / 2 - big * 0.04, y + big * 1.62); }
    c.globalAlpha = 1;
  }

  // ---------- نووسینی جوڵاو ----------
  function drawText(c, t, o, W, H) {
    var th = theme(o), size = o.size, lh = size * 1.55, lines = String(o.text).split('\n').filter(function (x) { return x.trim() !== ''; });
    if (!lines.length) return;
    var cy = o.pos === 'bottom' ? H * 0.76 : H * 0.5, y0 = cy - (lines.length - 1) * lh / 2, col = o.theme === 'light' ? '#0a1a14' : '#ffffff';
    c.direction = 'rtl'; c.font = '700 ' + size + 'px ' + FONT; c.textBaseline = 'middle';
    var a0 = env(t, o.dur);
    lines.forEach(function (ln, i) {
      var y = y0 + i * lh, fw = c.measureText(ln).width, rightX = o.align === 'right' ? W - W * 0.08 : W / 2 + fw / 2, p;
      c.textAlign = 'right'; c.globalAlpha = a0; c.fillStyle = col;
      if (o.style === 'rise') { p = cl((t - i * 0.18) / 0.55); c.globalAlpha = a0 * p; c.fillText(ln, rightX, y + (1 - E.outCubic(p)) * 60); }
      else if (o.style === 'pop') {
        p = cl((t - i * 0.12) / 0.5); var s = 0.5 + 0.5 * E.outBack(p);
        c.save(); c.translate(rightX - fw / 2, y); c.scale(s, s); c.globalAlpha = a0 * cl(p * 2); c.textAlign = 'center'; c.fillText(ln, 0, 0); c.restore();
      } else if (o.style === 'type') {
        var n = Math.floor(ln.length * cl((t - i * 0.6) / Math.max(0.4, o.dur * 0.35))); c.fillText(ln.slice(0, n), rightX, y);
      } else if (o.style === 'words') {
        var ws = ln.split(/\s+/), k = (t - i * 0.5) / 0.28, whole = Math.floor(Math.max(0, k)), part = cl(k - whole);
        if (whole >= ws.length) c.fillText(ln, rightX, y);
        else {
          if (whole + 1 <= ws.length && k > 0) { c.globalAlpha = a0 * part; c.fillText(ws.slice(0, whole + 1).join(' '), rightX, y + (1 - part) * 14); }
          c.globalAlpha = a0; if (whole > 0) c.fillText(ws.slice(0, whole).join(' '), rightX, y);
        }
      } else if (o.style === 'highlight') {
        p = E.outCubic(cl((t - i * 0.2) / 0.55)); var pad = size * 0.28, bx = rightX - fw - pad, bw = fw + pad * 2;
        c.fillStyle = o.accent; c.globalAlpha = a0; rr(c, bx + bw * (1 - p), y - size * 0.62, bw * p, size * 1.24, size * 0.16); c.fill();
        c.fillStyle = '#0a1a14'; c.globalAlpha = a0 * cl((p - 0.35) * 2); c.fillText(ln, rightX, y);
      }
    });
    c.globalAlpha = 1;
  }

  // ---------- چارت ----------
  A.parseData = function (txt) {
    var out = [];
    String(txt).split('\n').forEach(function (ln) {
      var i = ln.lastIndexOf(':'); if (i < 1) return;
      var v = parseFloat(String(ln.slice(i + 1)).replace(/[٠-٩]/g, function (d) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); }).replace(/[,٬]/g, ''));
      if (isFinite(v)) out.push({ label: ln.slice(0, i).trim(), value: v });
    });
    return out.slice(0, 8);
  };
  function drawChart(c, t, o, W, H) {
    var th = theme(o), data = o.data; if (!data.length) return;
    var cw = W * 0.82, ch = H * 0.62, cx = (W - cw) / 2, cy = (H - ch) / 2, max = 0, i;
    data.forEach(function (d) { max = Math.max(max, d.value); }); if (max <= 0) max = 1;
    c.globalAlpha = env(t, o.dur); c.direction = 'rtl';
    c.fillStyle = th.bg; rr(c, cx, cy, cw, ch, 28); c.fill();
    c.fillStyle = th.stripe; rr(c, cx + cw - 14, cy, 14, ch, 7); c.fill();
    c.textAlign = 'center'; c.textBaseline = 'alphabetic';
    if (o.title) { c.fillStyle = th.t1; c.font = '700 ' + Math.round(H * 0.048) + 'px ' + FONT; c.fillText(o.title, cx + cw / 2, cy + ch * 0.14); }
    var top = cy + ch * 0.24, base = cy + ch - ch * 0.16, area = base - top - 40, slot = (cw - 100) / data.length, bw = Math.min(slot * 0.58, 160);
    var hi = 0; data.forEach(function (d, k) { if (d.value > data[hi].value) hi = k; });
    for (i = 0; i < data.length; i++) {
      var p = E.outCubic(cl((t - 0.25 - i * 0.12) / 0.9)), x = cx + cw - 50 - (i + 0.5) * slot, h = area * (data[i].value / max) * p;
      c.fillStyle = i === hi ? o.accent : (o.theme === 'light' ? '#8fb6a2' : '#2b6a4d');
      rr(c, x - bw / 2, base - h, bw, Math.max(h, 1), 12); c.fill();
      c.fillStyle = th.t1; c.font = '700 ' + Math.round(H * 0.036) + 'px ' + FONT;
      c.fillText(L2.formatNumber(data[i].value * p, { decimals: o.decimals, digits: o.digits }), x, base - h - 16);
      c.fillStyle = th.t2; c.font = '500 ' + Math.round(H * 0.03) + 'px ' + FONT;
      var lb = data[i].label; if (lb.length > 14) lb = lb.slice(0, 13) + '…'; c.fillText(lb, x, base + H * 0.05);
    }
    c.globalAlpha = 1;
  }

  // ---------- ڕێکخستنی ڕووکار ----------
  function num(id, d) { var v = parseFloat(KZ.$(id).value); return isFinite(v) ? v : d; }
  A.size = function () { return KZ.$('#an-fmt').value === 'v' ? { W: 1080, H: 1920 } : { W: 1920, H: 1080 }; };
  A.options = function () {
    var kind = KZ.$('#an-kind .on').getAttribute('data-v'), z = A.size();
    return {
      kind: kind, W: z.W, H: z.H, dur: num('#an-dur', 4), fps: parseInt(KZ.$('#an-fps').value, 10) || 30,
      theme: KZ.$('#an-theme').value, accent: KZ.$('#an-accent').value, pos: KZ.$('#an-pos').value, digits: KZ.$('#an-digits').value,
      from: num('#an-from', 0), to: num('#an-to', 100), decimals: Math.max(0, num('#an-dec', 0)), prefix: KZ.$('#an-prefix').value, suffix: KZ.$('#an-suffix').value, label: KZ.$('#an-label').value,
      text: KZ.$('#an-text').value, style: KZ.$('#an-style').value, size: num('#an-size', 90), align: KZ.$('#an-align').value,
      title: KZ.$('#an-title').value, data: A.parseData(KZ.$('#an-data').value)
    };
  };
  A.drawFrame = function (c, t, o) {
    c.clearRect(0, 0, o.W, o.H);
    if (o.kind === 'counter') drawCounter(c, t, o, o.W, o.H);
    else if (o.kind === 'text') drawText(c, t, o, o.W, o.H);
    else drawChart(c, t, o, o.W, o.H);
  };
  A.preview = function () {
    var cv = KZ.$('#an-prev'); if (!cv) return;
    var o = A.options(), t = o.dur * (parseInt(KZ.$('#an-scrub').value, 10) / 100);
    cv.width = o.W; cv.height = o.H;
    var go = function () { A.drawFrame(cv.getContext('2d'), t, o); };
    try { document.fonts.load('700 40px "IBM Plex Sans Arabic"').then(go, go); } catch (e) { go(); }
    go();
  };
  A.showKind = function () {
    var k = KZ.$('#an-kind .on').getAttribute('data-v');
    KZ.$$('.an-grp').forEach(function (g) { g.classList.toggle('hide', g.getAttribute('data-for').split(' ').indexOf(k) < 0); });
    A.preview();
  };

  // ---------- ڕەندەر: وێنەکان ← ffmpeg ← .mov ی ئەلفا ----------
  A.render = async function (o, onProg) {
    var ff = KZ.ffmpeg(); if (!ff) throw new Error('ffmpeg نەدۆزرایەوە');
    try { await document.fonts.load('700 40px "IBM Plex Sans Arabic"'); } catch (e) {}
    var dir = KZ.tmp('anim_' + Date.now()); fs.mkdirSync(dir);
    var cv = document.createElement('canvas'); cv.width = o.W; cv.height = o.H;
    var c = cv.getContext('2d'), n = Math.max(2, Math.round(o.dur * o.fps)), i, b64;
    for (i = 0; i < n; i++) {
      A.drawFrame(c, i / o.fps, o);
      b64 = cv.toDataURL('image/png').replace(/^data:image\/png;base64,/, '');
      fs.writeFileSync(path.join(dir, 'f_' + ('00000' + i).slice(-5) + '.png'), Buffer.from(b64, 'base64'));
      if (i % 3 === 0) { onProg && onProg(i / n * 0.8); await new Promise(function (r) { setTimeout(r, 0); }); }
    }
    var out = path.join(KZ.workDir(), 'anim_' + o.kind + '_' + Date.now() + '.mov');
    onProg && onProg(0.85);
    var r = await KZ.exec(ff, ['-y', '-hide_banner', '-framerate', String(o.fps), '-i', path.join(dir, 'f_%05d.png'), '-c:v', 'prores_ks', '-profile:v', '4', '-pix_fmt', 'yuva444p10le', out]);
    await KZ.exec(KZ.isWin ? 'cmd' : 'rm', KZ.isWin ? ['/c', 'rmdir', '/s', '/q', dir] : ['-rf', dir]);
    if (r.code !== 0) throw new Error('ffmpeg: ' + r.err.slice(-200));
    onProg && onProg(1);
    return out;
  };

  // ---------- ناوچەی سەلامەت ----------
  A.drawSafe = function (cv, kind) {
    var s = L2.safeSpec(kind), c = cv.getContext('2d'); cv.width = s.W; cv.height = s.H; c.clearRect(0, 0, s.W, s.H);
    c.direction = 'rtl'; c.textAlign = 'center'; c.font = '600 40px ' + FONT;
    s.unsafe.forEach(function (u) {
      c.fillStyle = 'rgba(255,90,90,0.22)'; c.fillRect(u.x, u.y, u.w, u.h);
      if (u.label) { c.fillStyle = 'rgba(255,255,255,0.9)'; c.fillText(u.label, u.x + u.w / 2, u.y + Math.min(u.h / 2, 60) + 10); }
    });
    function box(b, col, lab, dash) {
      c.strokeStyle = col; c.lineWidth = 4; c.setLineDash(dash ? [18, 12] : []); c.strokeRect(b.x, b.y, b.w, b.h); c.setLineDash([]);
      if (lab) { c.fillStyle = col; c.textAlign = 'right'; c.fillText(lab, b.x + b.w - 14, b.y + 38); }
    }
    if (s.action) box(s.action, '#f2c14e', 'ناوچەی جوڵە ٩٣٪', true);
    box(s.safe, '#3ddc97', kind === 'tv' ? 'ناوچەی نووسین ٩٠٪' : 'ناوچەی سەلامەت', false);
    c.strokeStyle = 'rgba(255,255,255,0.35)'; c.lineWidth = 2; c.beginPath();
    c.moveTo(s.W / 2 - 30, s.H / 2); c.lineTo(s.W / 2 + 30, s.H / 2); c.moveTo(s.W / 2, s.H / 2 - 30); c.lineTo(s.W / 2, s.H / 2 + 30); c.stroke();
  };
  A.saveSafe = function (kind) {
    var cv = document.createElement('canvas'); A.drawSafe(cv, kind);
    var p = path.join(KZ.workDir(), 'safe_' + kind + '_' + Date.now() + '.png');
    fs.writeFileSync(p, Buffer.from(cv.toDataURL('image/png').replace(/^data:image\/png;base64,/, ''), 'base64'));
    return p;
  };
})();
