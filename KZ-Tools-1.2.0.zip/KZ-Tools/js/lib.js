/* KZ Tools — فەنکشنە پاکەکان (بێ پشت بەستن بە Premiere) */
(function () {
  'use strict';
  var LIB = {};

  // دەرهێنانی بێدەنگی لە دەرچووی ffmpeg silencedetect
  LIB.parseSilence = function (stderr, totalDur) {
    var re = /silence_(start|end):\s*(-?[\d.]+)/g, m, out = [], cur = null;
    while ((m = re.exec(stderr))) {
      var v = parseFloat(m[2]);
      if (m[1] === 'start') { cur = { s: Math.max(0, v), e: null }; out.push(cur); }
      else if (cur && cur.e === null) { cur.e = v; }
    }
    var i; for (i = 0; i < out.length; i++) if (out[i].e === null) out[i].e = totalDur;
    return out;
  };

  // گۆڕینی کاتی سەرچاوە بۆ کاتی تایم‌لاین + پاداش (ئاسوودەیی بۆ هەناسە)
  LIB.toSeqRanges = function (silences, clipStart, clipDur, pad, minKeep) {
    var out = [], i, s, e;
    for (i = 0; i < silences.length; i++) {
      s = silences[i].s + pad; e = Math.min(silences[i].e, clipDur) - pad;
      if (e - s < (minKeep || 0.1)) continue;
      out.push({ s: clipStart + s, e: clipStart + e });
    }
    return out;
  };

  LIB.totalLen = function (r) { var t = 0, i; for (i = 0; i < r.length; i++) t += r[i].e - r[i].s; return t; };

  // SRT
  function tsToSec(t) { var m = /(\d+):(\d+):(\d+)[,.](\d+)/.exec(t); return m ? (+m[1]) * 3600 + (+m[2]) * 60 + (+m[3]) + (+m[4]) / 1000 : 0; }
  LIB.parseSrt = function (txt) {
    var blocks = String(txt).replace(/\r/g, '').split(/\n\n+/), out = [], i, lines, m;
    for (i = 0; i < blocks.length; i++) {
      lines = blocks[i].split('\n').filter(function (x) { return x.trim() !== ''; });
      if (lines.length < 2) continue;
      m = /(\S+)\s*-->\s*(\S+)/.exec(lines[1] && /-->/.test(lines[1]) ? lines[1] : lines[0]);
      if (!m) continue;
      out.push({ s: tsToSec(m[1]), e: tsToSec(m[2]), text: lines.slice(/-->/.test(lines[0]) ? 1 : 2).join('\n') });
    }
    return out;
  };
  function secToTs(x) {
    var ms = Math.round(x * 1000), h = Math.floor(ms / 3600000); ms -= h * 3600000;
    var m = Math.floor(ms / 60000); ms -= m * 60000; var s = Math.floor(ms / 1000); ms -= s * 1000;
    function z(n, l) { n = String(n); while (n.length < l) n = '0' + n; return n; }
    return z(h, 2) + ':' + z(m, 2) + ':' + z(s, 2) + ',' + z(ms, 3);
  }
  LIB.buildSrt = function (items) {
    var o = [], i; for (i = 0; i < items.length; i++) o.push((i + 1) + '\n' + secToTs(items[i].s) + ' --> ' + secToTs(items[i].e) + '\n' + items[i].text + '\n');
    return o.join('\n');
  };

  LIB.safeName = function (s) { return String(s).replace(/[^\w\u0600-\u06FF\- ]+/g, '_').replace(/\s+/g, '_').slice(0, 60) || 'clip'; };


  // ---------- ژێرنووس ----------
  LIB.normalizeKurdish = function (t) {
    return String(t).replace(/ي/g, 'ی').replace(/ى/g, 'ی').replace(/ك/g, 'ک').replace(/ة/g, 'ە').replace(/ۀ/g, 'ە');
  };
  LIB.shiftSrt = function (items, sec) {
    return items.map(function (x) { return { s: Math.max(0, x.s + sec), e: Math.max(0, x.e + sec), text: x.text }; });
  };
  LIB.wrapLines = function (text, n) {
    var words = String(text).replace(/\s*\n\s*/g, ' ').split(/\s+/), lines = [], cur = '', i;
    for (i = 0; i < words.length; i++) {
      if (cur && (cur + ' ' + words[i]).length > n) { lines.push(cur); cur = words[i]; }
      else cur = cur ? cur + ' ' + words[i] : words[i];
    }
    if (cur) lines.push(cur);
    return lines.join('\n');
  };

  // ---------- ffmpeg ----------
  function hms(m) { return (+m[1]) * 3600 + (+m[2]) * 60 + parseFloat(m[3]); }
  LIB.parseDuration = function (txt) { var m = /Duration:\s*(\d+):(\d+):([\d.]+)/.exec(txt); return m ? hms(m) : 0; };
  LIB.parseTime = function (txt) {
    var re = /time=(\d+):(\d+):([\d.]+)/g, m, last = null;
    while ((m = re.exec(txt))) last = m;
    return last ? hms(last) : -1;
  };
  LIB.CONVERT = {
    social: { ext: 'mp4', args: ['-vf', "scale='min(1920,iw)':-2", '-c:v', 'libx264', '-preset', 'medium', '-crf', '20', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart'] },
    small: { ext: 'mp4', args: ['-vf', "scale='min(1280,iw)':-2", '-c:v', 'libx264', '-preset', 'fast', '-crf', '28', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '128k', '-movflags', '+faststart'] },
    vertical: { ext: 'mp4', args: ['-filter_complex', '[0:v]split[a][b];[a]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,boxblur=30:5[bg];[b]scale=1080:-2[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2,format=yuv420p[v]', '-map', '[v]', '-map', '0:a?', '-c:v', 'libx264', '-preset', 'medium', '-crf', '20', '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart'] },
    mp3: { ext: 'mp3', args: ['-vn', '-c:a', 'libmp3lame', '-q:a', '2'] },
    wav: { ext: 'wav', args: ['-vn', '-c:a', 'pcm_s16le', '-ar', '48000'] }
  };

  if (typeof window !== 'undefined') window.KZ_LIB = LIB;
  if (typeof module !== 'undefined' && module.exports) module.exports = LIB;
})();
