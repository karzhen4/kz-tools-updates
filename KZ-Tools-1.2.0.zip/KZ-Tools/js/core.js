/* KZ Tools — core helpers. گەشەپێدەر: کارژین خیرالله */
(function () {
  'use strict';
  var KZ = window.KZ = window.KZ || {};
  var fs = require('fs'), path = require('path'), os = require('os'), cp = require('child_process');
  var cep = window.__adobe_cep__;

  KZ.isWin = process.platform === 'win32';
  KZ.home = os.homedir();
  KZ.dataDir = path.join(KZ.home, '.kz-tools');
  try { if (!fs.existsSync(KZ.dataDir)) fs.mkdirSync(KZ.dataDir); } catch (e) {}

  // ڕێڕەوی فۆڵدەری ئێکستەنشن
  KZ.extDir = (function () {
    var u = decodeURI(cep.getSystemPath('extension'));
    u = u.replace(/^file:\/\/\//, KZ.isWin ? '' : '/').replace(/^file:\/\//, '');
    return u;
  })();

  KZ.version = (function () {
    try { return JSON.parse(fs.readFileSync(path.join(KZ.extDir, 'version.json'), 'utf8')); }
    catch (e) { return { version: '0.0.0', owner: 'کارژین خیرالله', updateUrl: '', trialDays: 3 }; }
  })();

  // ---------- پەیوەندی لەگەڵ Premiere (ExtendScript) ----------
  KZ.jsx = function (fn, arg) {
    return new Promise(function (resolve) {
      var call = 'KZ_HOST.' + fn + '(' + JSON.stringify(JSON.stringify(arg === undefined ? {} : arg)) + ')';
      cep.evalScript(call, function (res) {
        var out;
        try { out = JSON.parse(res); } catch (e) { out = { ok: false, error: 'وەڵامی نادروست لە Premiere: ' + String(res).slice(0, 200) }; }
        resolve(out);
      });
    });
  };

  // ---------- ڕێکخستنەکان ----------
  var setFile = path.join(KZ.dataDir, 'settings.json');
  KZ.settings = {};
  try { KZ.settings = JSON.parse(fs.readFileSync(setFile, 'utf8')); } catch (e) { KZ.settings = {}; }
  KZ.saveSettings = function () { try { fs.writeFileSync(setFile, JSON.stringify(KZ.settings, null, 2)); } catch (e) {} };
  KZ.getSetting = function (k, d) { return KZ.settings[k] === undefined ? d : KZ.settings[k]; };
  KZ.setSetting = function (k, v) { KZ.settings[k] = v; KZ.saveSettings(); };

  // ---------- جێبەجێکردنی فەرمان ----------
  KZ.exec = function (cmd, args, opts) {
    opts = opts || {};
    return new Promise(function (resolve) {
      var out = '', err = '', child;
      try {
        child = cp.spawn(cmd, args, { env: KZ.env() });
      } catch (e) { return resolve({ code: -1, out: '', err: String(e) }); }
      if (opts.onChild) opts.onChild(child);
      child.stdout.on('data', function (d) { out += d; if (opts.onOut) opts.onOut(String(d)); });
      child.stderr.on('data', function (d) { err += d; if (opts.onErr) opts.onErr(String(d)); });
      child.on('error', function (e) { resolve({ code: -1, out: out, err: String(e) }); });
      child.on('close', function (code) { resolve({ code: code, out: out, err: err }); });
    });
  };
  KZ.env = function () {
    var e = {}, k;
    for (k in process.env) e[k] = process.env[k];
    if (!KZ.isWin) e.PATH = '/opt/homebrew/bin:/usr/local/bin:/opt/local/bin:/usr/bin:/bin:' + (e.PATH || '');
    return e;
  };
  KZ.which = function (names) {
    var dirs = (KZ.env().PATH || '').split(KZ.isWin ? ';' : ':'), i, j, p;
    dirs.unshift(path.join(KZ.dataDir, 'bin'), path.join(KZ.extDir, 'runtime'));
    for (i = 0; i < names.length; i++) for (j = 0; j < dirs.length; j++) {
      p = path.join(dirs[j], names[i] + (KZ.isWin ? '.exe' : ''));
      try { if (fs.existsSync(p)) return p; } catch (e) {}
    }
    return null;
  };
  KZ.ffmpeg = function () { return KZ.which(['ffmpeg']); };
  KZ.ffprobe = function () { return KZ.which(['ffprobe']); };
  KZ.whisper = function () { return KZ.which(['whisper-cli', 'whisper-cpp', 'whisper']); };

  KZ.tmp = function (name) {
    var d = path.join(os.tmpdir(), 'kz-tools'); try { fs.mkdirSync(d); } catch (e) {}
    return path.join(d, name);
  };
  KZ.workDir = function () {
    var d = KZ.getSetting('workDir', path.join(KZ.home, 'Documents', 'KZ Tools'));
    try { fs.mkdirSync(d, { recursive: true }); } catch (e) {}
    return d;
  };

  // ---------- پەیامەکان و پێشکەوتن ----------
  KZ.$ = function (s, r) { return (r || document).querySelector(s); };
  KZ.$$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  KZ.toast = function (msg, kind) {
    var t = KZ.$('#toast'); if (!t) return;
    t.textContent = msg; t.className = 'toast show ' + (kind || '');
    clearTimeout(KZ._tt); KZ._tt = setTimeout(function () { t.className = 'toast'; }, 4200);
  };
  KZ.log = function (msg) {
    var l = KZ.$('#log'); if (!l) return;
    var d = new Date(), hh = ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2) + ':' + ('0' + d.getSeconds()).slice(-2);
    l.textContent += '[' + hh + '] ' + msg + '\n'; l.scrollTop = l.scrollHeight;
  };
  KZ.progress = function (p, label) {
    var bar = KZ.$('#prog'); if (!bar) return;
    bar.className = 'prog' + (p < 0 ? '' : ' on');
    KZ.$('#prog-fill').style.width = Math.max(0, Math.min(100, p)) + '%';
    KZ.$('#prog-label').textContent = label || '';
  };
  KZ.fmt = function (sec) {
    sec = Math.max(0, sec); var m = Math.floor(sec / 60), s = (sec - m * 60).toFixed(1);
    return m + ':' + (s < 10 ? '0' : '') + s;
  };

  // دابەزاندنی فایل (دوای ڕیدایرێکت)
  KZ.download = function (url, dest, onProg, hops) {
    hops = hops || 0;
    return new Promise(function (resolve, reject) {
      if (hops > 6) return reject(new Error('ڕیدایرێکتی زۆر'));
      var lib = /^https:/i.test(url) ? require('https') : require('http');
      var req = lib.get(url, { headers: { 'User-Agent': 'KZ-Tools' } }, function (res) {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          res.resume();
          return KZ.download(require('url').resolve(url, res.headers.location), dest, onProg, hops + 1).then(resolve, reject);
        }
        if (res.statusCode !== 200) { res.resume(); return reject(new Error('HTTP ' + res.statusCode)); }
        var total = parseInt(res.headers['content-length'] || '0', 10), got = 0, f = fs.createWriteStream(dest);
        res.on('data', function (c) { got += c.length; if (onProg && total) onProg(got / total); });
        res.pipe(f);
        f.on('finish', function () { f.close(function () { resolve(dest); }); });
        f.on('error', reject);
      });
      req.on('error', reject);
      req.setTimeout(30000, function () { req.abort(); reject(new Error('کاتی پەیوەندی تەواو بوو')); });
    });
  };
  KZ.fetchText = function (url) {
    return new Promise(function (resolve, reject) {
      var lib = /^https:/i.test(url) ? require('https') : require('http');
      lib.get(url + (url.indexOf('?') < 0 ? '?' : '&') + 't=' + Date.now(), { headers: { 'User-Agent': 'KZ-Tools' } }, function (res) {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          res.resume(); return KZ.fetchText(require('url').resolve(url, res.headers.location)).then(resolve, reject);
        }
        if (res.statusCode !== 200) { res.resume(); return reject(new Error('HTTP ' + res.statusCode)); }
        var b = ''; res.setEncoding('utf8'); res.on('data', function (c) { b += c; }); res.on('end', function () { resolve(b); });
      }).on('error', reject);
    });
  };
})();
