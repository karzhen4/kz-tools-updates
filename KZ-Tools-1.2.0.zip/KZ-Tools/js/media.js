/* KZ Tools — ئامرازەکانی بەشی دووەم: ئەنیمەیشن، خێرایی، ساوند، دەنگی زیرەک، شەپۆل، LUT، تۆمار، ناوچەی سەلامەت، ترانزیشن */
(function () {
  'use strict';
  var KZ = window.KZ, L1 = window.KZ_LIB, L2 = window.KZ_LIB2, T = KZ.tools, fs = require('fs'), path = require('path'), A = KZ.anim;
  var busy = false;

  function gate() {
    if (!KZ.license.canUse()) { KZ.toast('کۆدی مۆڵەت پێویستە', 'bad'); return false; }
    if (busy) { KZ.toast('کارێکی تر ماوە', 'bad'); return false; }
    return true;
  }
  async function guard(fn) {
    if (!gate()) return;
    busy = true;
    try { await fn(); } catch (e) { KZ.toast('هەڵە: ' + (e && e.message || e), 'bad'); KZ.log('هەڵە: ' + (e && e.message || e)); }
    busy = false; KZ.progress(-1);
  }
  function ff() { var f = KZ.ffmpeg(); if (!f) KZ.toast('ffmpeg نەدۆزرایەوە. لە «ڕێکخستن» دایبەزێنە', 'bad'); return f; }
  async function sel() { var r = await KZ.jsx('getSelection'); if (!r.ok) { KZ.toast(r.error, 'bad'); return null; } return r; }
  async function firstClip() {
    var r = await sel(); if (!r) return null;
    var c = (r.clips || []).filter(function (x) { return x.path; })[0];
    if (!c) { KZ.toast('کلیپێکی خاوەن فایل هەڵبژێرە', 'bad'); return null; }
    return { clip: c, info: r };
  }
  function outPath(name, ext) { return path.join(KZ.workDir(), L1.safeName(name) + '_' + Date.now() + '.' + ext); }
  function numv(id, d) { var v = parseFloat(KZ.$(id).value); return isFinite(v) ? v : d; }
  function trk(id, d) { return Math.max(0, (parseInt(KZ.$(id).value, 10) || d) - 1); }
  // جێبەجێکردنی ffmpeg لەگەڵ پێشکەوتن
  async function runFF(args, label, total) {
    var buf = '', tot = total || 0;
    var r = await KZ.exec(ff(), args, { onErr: function (d) {
      buf = (buf + d).slice(-3000); if (!tot) tot = L1.parseDuration(buf);
      var t = L1.parseTime(d); if (tot && t >= 0) KZ.progress(Math.min(99, t / tot * 100), label + ' ' + Math.round(Math.min(100, t / tot * 100)) + '%');
    } });
    if (r.code !== 0) throw new Error('ffmpeg: ' + (r.err || '').slice(-220));
    return r;
  }

  // ---------- ئەنیمەیشن ----------
  T.animRender = function () {
    return guard(async function () {
      if (!ff()) return;
      var o = A.options();
      if (o.kind === 'chart' && !o.data.length) { KZ.toast('زانیاری چارت بنووسە: ناو:ژمارە', 'bad'); return; }
      KZ.progress(1, 'ڕەندەری فرەیمەکان...');
      var out = await A.render(o, function (p) { KZ.progress(p * 100, 'ڕەندەر ' + Math.round(p * 100) + '%'); });
      var s = await sel(); if (!s) return;
      var r = await KZ.jsx('placeVideo', { path: out, at: s.playhead, track: trk('#an-vt', 3) });
      if (!r.ok) { KZ.toast('دروست بوو بەڵام دانان نەکرا: ' + r.error, 'bad'); KZ.log(out); return; }
      KZ.toast('ئەنیمەیشن لە پلەیهێد دانرا');
    });
  };

  // ---------- خێرایی ----------
  async function hasAudio(src) { var r = await KZ.exec(ff(), ['-hide_banner', '-i', src]); return /Audio:/.test(r.err); }
  T.speed = function () {
    return guard(async function () {
      if (!ff()) return;
      var p = await firstClip(); if (!p) return;
      var c = p.clip, dur = c.outPoint - c.inPoint, mode = KZ.$('#sp-mode .on').getAttribute('data-v'), st;
      if (mode === 'const') st = [{ p: 1, speed: Math.max(0.1, Math.min(8, numv('#sp-s', 1.5))) }];
      else st = [{ p: numv('#sp-p1', 30), speed: numv('#sp-s1', 1) }, { p: numv('#sp-p2', 40), speed: numv('#sp-s2', 0.35) }, { p: numv('#sp-p3', 30), speed: numv('#sp-s3', 1) }];
      st = st.filter(function (x) { return x.p > 0 && x.speed > 0; });
      if (!st.length) { KZ.toast('ڕێکخستنەکان هەڵەن', 'bad'); return; }
      var ha = await hasAudio(c.path), out = outPath(c.name + '_speed', 'mp4'), expect = L2.speedOutDuration(dur, st);
      KZ.progress(2, 'گۆڕینی خێرایی...');
      await runFF(L2.speedArgs({ src: c.path, inSec: c.inPoint, dur: dur, hasAudio: ha, stages: st, out: out }), 'خێرایی', expect);
      var r = await KZ.jsx('placeVideo', { path: out, at: c.start, track: trk('#sp-vt', 2) });
      KZ.toast(r.ok ? 'کلیپی نوێ دانرا (' + KZ.fmt(expect) + ')' : 'دروست بوو: ' + (r.error || out), r.ok ? '' : 'bad');
    });
  };

  // ---------- ساوند ئێفێکت ----------
  var sfxSel = 'whoosh';
  async function sfxFile(name) {
    var dir = path.join(KZ.workDir(), 'SFX'); try { fs.mkdirSync(dir); } catch (e) {}
    var f = path.join(dir, 'KZ_' + name + '.wav');
    if (!fs.existsSync(f)) { var r = await KZ.exec(ff(), L2.sfxArgs(name, f)); if (r.code !== 0) throw new Error('دروستکردنی ساوند سەرکەوتوو نەبوو'); }
    return f;
  }
  T.sfxBuild = function () {
    var box = KZ.$('#sx-list'); box.innerHTML = '';
    Object.keys(L2.SFX).forEach(function (k) {
      var b = document.createElement('button'); b.type = 'button'; b.textContent = L2.SFX[k].label; b.setAttribute('data-v', k);
      if (k === sfxSel) b.className = 'on';
      b.onclick = function () { sfxSel = k; KZ.$$('#sx-list button').forEach(function (x) { x.classList.toggle('on', x === b); }); };
      box.appendChild(b);
    });
  };
  T.sfxPlay = function () {
    return guard(async function () {
      if (!ff()) return;
      var f = await sfxFile(sfxSel);
      try { if (T._au) T._au.pause(); T._au = new Audio('file://' + encodeURI(f)); await T._au.play(); } catch (e) { KZ.toast('گوێگرتن لێرە نایەت: ' + f); }
    });
  };
  T.sfxPlace = function () {
    return guard(async function () {
      if (!ff()) return;
      var f = await sfxFile(sfxSel), s = await sel(); if (!s) return;
      var im = await KZ.jsx('importFile', { path: f });
      if (!im.ok) { KZ.toast('هاوردەکردن سەرکەوتوو نەبوو', 'bad'); return; }
      var r = await KZ.jsx('placeAudio', { path: f, track: trk('#sx-at', 3), at: s.playhead });
      KZ.toast(r.ok ? 'ساوند دانرا' : r.error, r.ok ? '' : 'bad');
    });
  };

  // ---------- دەنگی زیرەک (ducking) ----------
  T.duck = function () {
    return guard(async function () {
      if (!ff()) return;
      var s = await sel(); if (!s) return;
      var au = (s.clips || []).filter(function (c) { return c.path && c.kind === 'audio'; });
      if (au.length < 2) { KZ.toast('دوو کلیپی دەنگ هەڵبژێرە: قسە (هێڵی خوارەوە) و موزیک (هێڵی سەرەوە)', 'bad'); return; }
      au.sort(function (a, b) { return a.track - b.track; });
      var v = au[0], m = au[1], out = outPath(m.name + '_duck', 'wav');
      KZ.progress(10, 'کەمکردنەوەی موزیک لەژێر قسە...');
      await runFF(L2.duckArgs({ path: m.path, inSec: m.inPoint, dur: m.outPoint - m.inPoint, start: m.start }, { path: v.path, inSec: v.inPoint, dur: v.outPoint - v.inPoint, start: v.start }, KZ.$('#dk-level').value, out), 'دەنگ', m.outPoint - m.inPoint);
      var im = await KZ.jsx('importFile', { path: out });
      var r = await KZ.jsx('placeAudio', { path: out, track: m.track, at: m.start });
      KZ.toast(r.ok ? 'موزیکی نوێ لەسەر A' + (m.track + 1) + ' دانرا (Cmd+Z بۆ گەڕانەوە)' : 'دروست بوو: ' + (r.error || out), r.ok ? '' : 'bad');
    });
  };

  // ---------- شەپۆلی دەنگ ----------
  T.viz = function () {
    return guard(async function () {
      if (!ff()) return;
      var p = await firstClip(); if (!p) return;
      var c = p.clip, dur = c.outPoint - c.inPoint, vert = KZ.$('#vz-fmt').value === 'v', W = vert ? 1080 : 1920, H = vert ? 1920 : 1080;
      var bh = Math.round(H * numv('#vz-h', 18) / 100), pos = KZ.$('#vz-pos').value, y = pos === 'top' ? Math.round(H * 0.08) : pos === 'center' ? Math.round((H - bh) / 2) : Math.round(H - bh - H * 0.1);
      var out = outPath(c.name + '_wave', 'mov');
      KZ.progress(2, 'دروستکردنی شەپۆل...');
      await runFF(L2.vizArgs({ src: c.path, inSec: c.inPoint, dur: dur, mode: KZ.$('#vz-mode').value, color: KZ.$('#vz-color').value, W: W, H: H, bandH: bh, y: y, out: out }), 'شەپۆل', dur);
      var r = await KZ.jsx('placeVideo', { path: out, at: c.start, track: trk('#vz-vt', 3) });
      KZ.toast(r.ok ? 'شەپۆل دانرا' : 'دروست بوو: ' + (r.error || out), r.ok ? '' : 'bad');
    });
  };

  // ---------- فلتەر (LUT) ----------
  function lutFile() {
    var look = KZ.$('#lk-look').value, k = numv('#lk-int', 80) / 100, dir = path.join(KZ.workDir(), 'LUTs'); try { fs.mkdirSync(dir); } catch (e) {}
    var f = path.join(dir, 'KZ-' + look + '-' + Math.round(k * 100) + '.cube');
    fs.writeFileSync(f, L2.cube(look, k, 33));
    return f;
  }
  T.lutPreview = function () {
    var cv = KZ.$('#lk-prev'); if (!cv) return;
    var w = 360, h = 110; cv.width = w; cv.height = h;
    var c = cv.getContext('2d'), im = c.createImageData(w, h), look = KZ.$('#lk-look').value, k = numv('#lk-int', 80) / 100, x, y, hsv, rgb, g, i, f, q, t, pp;
    function hsv2rgb(hh, s, v) {
      var i2 = Math.floor(hh * 6), f2 = hh * 6 - i2, p2 = v * (1 - s), q2 = v * (1 - f2 * s), t2 = v * (1 - (1 - f2) * s);
      return [[v, t2, p2], [q2, v, p2], [p2, v, t2], [p2, q2, v], [t2, p2, v], [v, p2, q2]][i2 % 6];
    }
    for (y = 0; y < h; y++) for (x = 0; x < w; x++) {
      if (y < 30) rgb = [x / w, x / w, x / w];                       // خەتی خۆڵەمێشی
      else rgb = hsv2rgb(x / w, 0.15 + 0.85 * ((y - 30) / (h - 30)), 0.95 - 0.55 * ((y - 30) / (h - 30)) * 0.4);
      g = L2.grade(look, rgb, k); i = (y * w + x) * 4;
      im.data[i] = g[0] * 255; im.data[i + 1] = g[1] * 255; im.data[i + 2] = g[2] * 255; im.data[i + 3] = 255;
    }
    c.putImageData(im, 0, 0);
  };
  T.lutSave = function () {
    try { var f = lutFile(); KZ.toast('LUT هەڵگیرا. لە Lumetri ← Creative ← Look بیدۆزەرەوە'); KZ.log(f); KZ.exec(KZ.isWin ? 'explorer' : 'open', [path.dirname(f)]); }
    catch (e) { KZ.toast('هەڵگرتن سەرکەوتوو نەبوو', 'bad'); }
  };
  T.lutRender = function () {
    return guard(async function () {
      if (!ff()) return;
      var p = await firstClip(); if (!p) return;
      var c = p.clip, dur = c.outPoint - c.inPoint, cube = lutFile(), out = outPath(c.name + '_look', 'mp4');
      KZ.progress(2, 'جێبەجێکردنی فلتەر...');
      await runFF(L2.lutRenderArgs({ src: c.path, inSec: c.inPoint, dur: dur, cube: cube, out: out }), 'فلتەر', dur);
      var r = await KZ.jsx('placeVideo', { path: out, at: c.start, track: trk('#lk-vt', 2) });
      KZ.toast(r.ok ? 'کلیپی ڕەنگکراو دانرا' : 'دروست بوو: ' + (r.error || out), r.ok ? '' : 'bad');
    });
  };

  // ---------- تۆمارکردنی شاشە ----------
  var rec = null;
  T.recDevices = function () {
    return guard(async function () {
      if (KZ.isWin) { KZ.toast('لە ویندۆز هەموو شاشەکە تۆمار دەکرێت'); return; }
      if (!ff()) return;
      var r = await KZ.exec(ff(), ['-hide_banner', '-f', 'avfoundation', '-list_devices', 'true', '-i', '']);
      var d = L2.parseAvfDevices(r.err), vs = KZ.$('#rc-video'), as = KZ.$('#rc-audio');
      vs.innerHTML = ''; as.innerHTML = '<option value="">بێ دەنگ</option>';
      d.video.forEach(function (x) { var o = document.createElement('option'); o.value = x.id; o.textContent = x.name; if (/screen/i.test(x.name) && !vs.value) o.selected = true; vs.appendChild(o); });
      d.audio.forEach(function (x) { var o = document.createElement('option'); o.value = x.id; o.textContent = x.name; as.appendChild(o); });
      KZ.toast(d.video.length ? 'ئامێرەکان دۆزرانەوە' : 'ئامێر نەدۆزرایەوە، مۆڵەتی تۆمارکردنی شاشە بدە', d.video.length ? '' : 'bad');
    });
  };
  T.recToggle = async function () {
    var btn = KZ.$('#rc-go');
    if (rec) {                                    // وەستاندن
      btn.disabled = true; try { rec.child.stdin.write('q'); } catch (e) {}
      setTimeout(function () { try { if (rec) rec.child.kill(); } catch (e) {} }, 6000);
      return;
    }
    if (!KZ.license.canUse()) { KZ.toast('کۆدی مۆڵەت پێویستە', 'bad'); return; }
    if (!ff()) return;
    var vid = KZ.$('#rc-video').value;
    if (!KZ.isWin && vid === '') { KZ.toast('سەرەتا «پشکنینی ئامێرەکان» دابگرە', 'bad'); return; }
    var out = outPath('screen', 'mp4'), h = parseInt(KZ.$('#rc-res').value, 10) || 0;
    var args = L2.recArgs({ win: KZ.isWin, video: vid, audio: KZ.$('#rc-audio').value, fps: 30, height: h, out: out });
    var t0 = Date.now(), tick = setInterval(function () { KZ.$('#rc-time').textContent = KZ.fmt((Date.now() - t0) / 1000); }, 500);
    btn.textContent = 'وەستاندن'; btn.classList.add('rec');
    rec = { out: out };
    var r = await KZ.exec(ff(), args, { onChild: function (c) { rec.child = c; } });
    clearInterval(tick); rec = null; btn.disabled = false; btn.classList.remove('rec'); btn.textContent = 'دەستپێکردنی تۆمار';
    if (!fs.existsSync(out) || fs.statSync(out).size < 2000) { KZ.toast('تۆمار سەرکەوتوو نەبوو. مۆڵەتی Screen Recording بۆ Premiere بدە', 'bad'); KZ.log((r.err || '').slice(-250)); return; }
    KZ.log('تۆمار: ' + out);
    var im = await KZ.jsx('importFile', { path: out });
    KZ.toast(im.ok ? 'تۆمار تەواو بوو و هاوردەکرا' : 'تۆمار تەواو بوو: ' + out);
  };

  // ---------- ناوچەی سەلامەت ----------
  T.safePreview = function () { var cv = KZ.$('#sf-prev'); if (cv) A.drawSafe(cv, KZ.$('#sf-kind').value); };
  T.safePlace = function () {
    return guard(async function () {
      var png = A.saveSafe(KZ.$('#sf-kind').value), s = await sel(); if (!s) return;
      var r = await KZ.jsx('placeImage', { path: png, at: s.playhead, track: trk('#sf-vt', 4), duration: 5, toEnd: true });
      KZ.toast(r.ok ? 'ڕێنمایی دانرا. دوای کار بیسڕەوە یان بیشارەوە' : r.error, r.ok ? '' : 'bad');
    });
  };

  // ---------- ترانزیشن ----------
  T.trans = function () {
    return guard(async function () {
      var r = await KZ.jsx('addTransitions', { name: KZ.$('#tr-name').value, duration: numv('#tr-dur', 0.5), skipFirst: KZ.$('#tr-skip').checked });
      KZ.toast(r.ok ? r.count + ' ترانزیشن زیادکرا' : r.error, r.ok ? '' : 'bad');
    });
  };

  // ---------- زووم: یەک‌لەدوای‌یەک و پەنچ لەسەر وشەکان ----------
  T.zoomAlt = function () {
    return guard(async function () {
      var r = await KZ.jsx('altZoom', { amount: numv('#zm-amt', 115) });
      KZ.toast(r.ok ? 'زووم بۆ ' + r.count + ' کلیپ دانرا' : r.error, r.ok ? '' : 'bad');
    });
  };
  T.zoomWords = function () {
    return guard(async function () {
      var f = ff(); if (!f) return; var wh = KZ.whisper();
      if (!wh) { KZ.toast('whisper نەدۆزرایەوە: brew install whisper-cpp', 'bad'); return; }
      var s = await sel(); if (!s) return;
      var c = (s.clips || []).filter(function (x) { return x.path; })[0]; if (!c) { KZ.toast('کلیپێک هەڵبژێرە', 'bad'); return; }
      var model = KZ.$('#zm-model').value, dir = path.join(KZ.dataDir, 'models'), mp = path.join(dir, 'ggml-' + model + '.bin');
      if (!fs.existsSync(mp)) { KZ.toast('مۆدێلی ' + model + ' نییە. سەرەتا لە «کاپشن» یەکجار بەکاری بهێنە', 'bad'); return; }
      var wav = KZ.tmp('zw_' + Date.now() + '.wav'), base = path.join(KZ.workDir(), 'words_' + Date.now());
      KZ.progress(20, 'دەرهێنانی دەنگ...');
      var r = await KZ.exec(f, ['-y', '-hide_banner', '-ss', String(c.inPoint), '-t', String(c.outPoint - c.inPoint), '-i', c.path, '-vn', '-ac', '1', '-ar', '16000', '-c:a', 'pcm_s16le', wav]);
      if (r.code !== 0) { KZ.toast('دەرهێنانی دەنگ سەرکەوتوو نەبوو', 'bad'); return; }
      KZ.progress(50, 'دۆزینەوەی وشەکان...');
      await KZ.exec(wh, ['-m', mp, '-f', wav, '-l', KZ.$('#zm-lang').value, '-osrt', '-of', base, '-ml', '1', '-sow']);
      try { fs.unlinkSync(wav); } catch (e) {}
      if (!fs.existsSync(base + '.srt')) { KZ.toast('وشەکان نەدۆزرانەوە', 'bad'); return; }
      var words = L1.parseSrt(fs.readFileSync(base + '.srt', 'utf8')), every = Math.max(1, parseInt(KZ.$('#zm-every').value, 10) || 4), times = [];
      words.forEach(function (w, i) { if (i % every === 0) times.push(c.start + w.s); });
      var out = await KZ.jsx('punchZoom', { times: times, amount: numv('#zm-amt', 115), hold: numv('#zm-hold', 0.6) });
      KZ.toast(out.ok ? out.count + ' پەنچی زووم دانرا' : out.error, out.ok ? '' : 'bad');
    });
  };
})();
