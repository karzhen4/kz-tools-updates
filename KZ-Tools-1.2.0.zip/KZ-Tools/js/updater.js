/* KZ Tools — نوێکردنەوەی خۆکار. manifest بە ئیمزای خاوەنەکە پشتڕاست دەکرێتەوە و zip بە sha256. */
(function () {
  'use strict';
  var KZ = window.KZ, fs = require('fs'), path = require('path'), crypto = require('crypto');
  var U = KZ.updater = {};

  function cmp(a, b) {
    a = String(a).split('.'); b = String(b).split('.');
    for (var i = 0; i < 3; i++) { var x = +a[i] || 0, y = +b[i] || 0; if (x !== y) return x > y ? 1 : -1; }
    return 0;
  }
  U.check = async function () {
    var url = KZ.version.updateUrl;
    if (!url) return { ok: false, error: 'ناونیشانی نوێکردنەوە ڕێکنەخراوە' };
    var txt;
    try { txt = await KZ.fetchText(url); } catch (e) { return { ok: false, error: 'پەیوەندی نەکرا: ' + e.message }; }
    var wrap, m;
    try {
      wrap = JSON.parse(txt);
      var pub = fs.readFileSync(path.join(KZ.extDir, 'license.pub'), 'utf8');
      var good = crypto.createVerify('SHA256').update(wrap.data).verify(pub, Buffer.from(wrap.sig, 'base64'));
      if (!good) return { ok: false, error: 'ئیمزای نوێکردنەوە دروست نییە، وەستێنرا' };
      m = JSON.parse(wrap.data);
    } catch (e) { return { ok: false, error: 'فایلی نوێکردنەوە تێکچووە' }; }
    if (m.revoked && m.revoked.length) KZ.license.setRevoked(m.revoked);   // لیستی لایسنسە هەڵوەشێنراوەکان
    return { ok: true, manifest: m, newer: cmp(m.version, KZ.version.version) > 0 };
  };

  U.install = async function (m, onProg) {
    if (!m.zipUrl) return { ok: false, error: 'zipUrl بەتاڵە' };
    var zip = KZ.tmp('kz-update.zip'), dir = KZ.tmp('kz-update');
    try {
      await KZ.download(m.zipUrl, zip, function (p) { if (onProg) onProg(p * 0.8); });
      var sha = crypto.createHash('sha256').update(fs.readFileSync(zip)).digest('hex');
      if (sha !== m.sha256) return { ok: false, error: 'sha256 ناگونجێت، فایلەکە دەستکاری کراوە یان تەواو نەبووە' };
      if (onProg) onProg(0.85);
      var r;
      if (KZ.isWin) {
        r = await KZ.exec('powershell', ['-NoProfile', '-Command', 'Remove-Item -Recurse -Force "' + dir + '" -ErrorAction SilentlyContinue; Expand-Archive -Force "' + zip + '" "' + dir + '"']);
      } else {
        await KZ.exec('rm', ['-rf', dir]);
        r = await KZ.exec('unzip', ['-o', '-q', zip, '-d', dir]);
      }
      if (r.code !== 0) return { ok: false, error: 'کردنەوەی zip سەرکەوتوو نەبوو: ' + r.err };
      var src = path.join(dir, 'KZ-Tools');
      if (!fs.existsSync(path.join(src, 'CSXS', 'manifest.xml'))) return { ok: false, error: 'پاکێجەکە ناوەڕۆکی دروستی نییە' };
      if (onProg) onProg(0.92);
      r = KZ.isWin
        ? await KZ.exec('xcopy', [src + '\\*', KZ.extDir + '\\', '/E', '/Y', '/Q'])
        : await KZ.exec('cp', ['-R', src + '/.', KZ.extDir + '/']);
      if (r.code !== 0) return { ok: false, error: 'کۆپیکردن سەرکەوتوو نەبوو: ' + r.err };
      if (onProg) onProg(1);
      return { ok: true };
    } catch (e) { return { ok: false, error: e.message }; }
  };
})();
