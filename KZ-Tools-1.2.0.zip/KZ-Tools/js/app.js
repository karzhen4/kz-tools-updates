/* KZ Tools — پەیوەندی ڕووکار */
(function () {
  'use strict';
  var KZ = window.KZ, $ = KZ.$, $$ = KZ.$$, T = KZ.tools, L2 = window.KZ_LIB2, pendingUpdate = null, curCat = 'edit';

  function showCat(cat) {
    curCat = cat;
    $$('#cats button').forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-cat') === cat); });
    $$('#tabs button').forEach(function (b) { b.classList.toggle('hide', b.getAttribute('data-cat') !== cat); });
  }
  function showTab(name) {
    var btn = $('#tabs button[data-tab="' + name + '"]');
    if (btn && btn.getAttribute('data-cat') !== curCat) showCat(btn.getAttribute('data-cat'));
    $$('#tabs button').forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-tab') === name); });
    $$('.pane').forEach(function (p) { p.classList.toggle('on', p.id === 'p-' + name); });
    var locked = !KZ.license.canUse() && name !== 'settings';
    $('#lock').classList.toggle('hide', !locked);
    if (name === 'settings') refreshSettings();
    if (name === 'anim') KZ.anim.showKind();
    if (name === 'luts') T.lutPreview();
    if (name === 'safe') T.safePreview();
    if (name === 'lower') KZ.lower.preview();
  }
  function refreshBadge() {
    var s = KZ.license.status(), b = $('#lic-badge');
    if (s.state === 'licensed') { b.textContent = 'چالاک' + (s.info.e ? ' · ' + s.info.e : ' · هەمیشەیی'); b.className = 'lic-badge ok'; }
    else if (s.state === 'trial') { b.textContent = 'تاقیکردنەوە · ' + Math.ceil(s.days) + ' ڕۆژ'; b.className = 'lic-badge trial'; }
    else { b.textContent = 'قفڵکراو'; b.className = 'lic-badge locked'; }
    return s;
  }
  function refreshSettings() {
    var s = refreshBadge();
    $('#st-state').textContent = s.state === 'licensed' ? 'چالاک (' + s.info.n + ')' : s.state === 'trial' ? 'تاقیکردنەوە' : 'قفڵکراو' + (s.error ? ' — ' + s.error : '');
    $('#st-dev').textContent = KZ.license.deviceId();
    $('#st-ver').textContent = KZ.version.version;
    $('#st-ff').textContent = KZ.ffmpeg() ? 'دۆزرایەوە' : 'نییە';
    $('#st-wh').textContent = KZ.whisper() ? 'دۆزرایەوە' : 'نییە';
    $('#st-work').value = KZ.workDir();
  }
  function seg(id, cb) {
    $$('#' + id + ' button').forEach(function (b) {
      b.onclick = function () { $$('#' + id + ' button').forEach(function (x) { x.classList.remove('on'); }); b.classList.add('on'); if (cb) cb(b.getAttribute('data-v')); };
    });
  }

  function init() {
    $$('#cats button').forEach(function (b) {
      b.onclick = function () {
        var cat = b.getAttribute('data-cat'); showCat(cat);
        var first = $('#tabs button[data-cat="' + cat + '"]'); if (first) showTab(first.getAttribute('data-tab'));
      };
    });
    $$('#tabs button').forEach(function (b) { b.onclick = function () { showTab(b.getAttribute('data-tab')); }; });
    $$('[data-goto]').forEach(function (b) { b.onclick = function () { showTab(b.getAttribute('data-goto')); }; });
    $('#lic-badge').onclick = function () { showTab('settings'); };
    seg('sl-mode'); seg('zm-mode'); seg('lt-style');
    seg('an-kind', function () { KZ.anim.showKind(); });
    seg('sp-mode', function (v) { $$('.sp-grp').forEach(function (g) { g.classList.toggle('hide', g.getAttribute('data-for') !== v); }); });

    $('#sl-run').onclick = T.silence;
    $('#cp-run').onclick = T.caption;
    $('#cp-srt').onclick = T.importSrt;
    $('#au-run').onclick = T.audio;
    $('#zm-run').onclick = T.zoom; $('#zm-alt').onclick = T.zoomAlt; $('#zm-words').onclick = T.zoomWords;
    $('#mg-run').onclick = T.mogrtInsert;
    $('#mg-folder').value = KZ.getSetting('mogrtDir', '');
    $('#mg-folder').onchange = T.mogrtLoad;
    $('#mg-browse').onclick = function () {
      var f = KZ.pickFolder('فۆڵدەری موگرت'); if (f) { $('#mg-folder').value = f; T.mogrtLoad(); } else KZ.toast('ڕێڕەوەکە بنووسە و Enter دابگرە');
    };
    $('#sr-open').onclick = T.srtOpen; $('#sr-last').onclick = T.srtLast; $('#sr-fix').onclick = T.srtFix;
    $('#sr-dowrap').onclick = T.srtWrap; $('#sr-doshift').onclick = T.srtShift; $('#sr-save').onclick = T.srtSave;
    $('#lt-place').onclick = T.lowerPlace; $('#lt-save').onclick = T.lowerSave;
    ['lt-l1', 'lt-l2', 'lt-theme', 'lt-accent', 'lt-side'].forEach(function (id) { $('#' + id).oninput = KZ.lower.preview; $('#' + id).onchange = KZ.lower.preview; });
    $$('#lt-style button').forEach(function (b) { b.addEventListener('click', function () { setTimeout(KZ.lower.preview, 0); }); });
    $('#cv-pick').onclick = T.convPick; $('#cv-clear').onclick = T.convClear; $('#cv-run').onclick = T.convert; $('#cv-cancel').onclick = T.convCancel;
    $('#tl-mhere').onclick = T.markHere; $('#tl-mevery').onclick = T.markEvery;
    $('#tl-mclear').onclick = T.markClear; $('#tl-org').onclick = T.organize;
    T.mogrtLoad();

    // بەشی دووەم
    $$('#p-anim input, #p-anim select, #p-anim textarea').forEach(function (e) { e.oninput = KZ.anim.preview; e.onchange = KZ.anim.preview; });
    $('#an-run').onclick = T.animRender;
    $('#sp-run').onclick = T.speed; $('#tr-run').onclick = T.trans; $('#dk-run').onclick = T.duck; $('#vz-run').onclick = T.viz;
    T.sfxBuild(); $('#sx-play').onclick = T.sfxPlay; $('#sx-place').onclick = T.sfxPlace;
    var lk = $('#lk-look'); Object.keys(L2.LOOKS).forEach(function (k) { var o = document.createElement('option'); o.value = k; o.textContent = L2.LOOKS[k].label; lk.appendChild(o); });
    lk.onchange = T.lutPreview;
    $('#lk-int').oninput = function () { $('#lk-int-v').textContent = this.value; T.lutPreview(); };
    $('#lk-save').onclick = T.lutSave; $('#lk-render').onclick = T.lutRender;
    $('#rc-dev').onclick = T.recDevices; $('#rc-go').onclick = T.recToggle;
    $('#sf-kind').onchange = T.safePreview; $('#sf-place').onclick = T.safePlace;

    // ڕێکخستن
    $('#st-copy').onclick = function () {
      var ta = document.createElement('textarea'); ta.value = KZ.license.deviceId(); document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); KZ.toast('کۆدی ئامێر لەبەرگیرایەوە'); } catch (e) {} document.body.removeChild(ta);
    };
    $('#st-act').onclick = function () {
      var r = KZ.license.activate($('#st-code').value);
      if (r.ok) { KZ.toast('مۆڵەت چالاک بوو. سوپاس ' + r.info.n); $('#st-code').value = ''; showTab('settings'); }
      else KZ.toast(r.error, 'bad');
    };
    $('#st-deact').onclick = function () { KZ.license.deactivate(); KZ.toast('مۆڵەت لابرا'); showTab('settings'); };
    $('#st-ffget').onclick = T.getFfmpeg;
    $('#st-work').onchange = function () { KZ.setSetting('workDir', this.value.trim()); };
    $('#st-upd').onclick = async function () {
      var msg = $('#st-upd-msg'); msg.textContent = 'پشکنین...';
      var r = await KZ.updater.check();
      if (!r.ok) { msg.textContent = r.error; return; }
      refreshBadge();
      if (r.newer) { pendingUpdate = r.manifest; msg.textContent = 'وەشانی ' + r.manifest.version + ' بەردەستە. ' + (r.manifest.notes || ''); $('#st-upd-go').classList.remove('hide'); }
      else msg.textContent = 'وەشانەکەت نوێترینە';
    };
    $('#st-upd-go').onclick = async function () {
      if (!pendingUpdate) return;
      var r = await KZ.updater.install(pendingUpdate, function (p) { KZ.progress(p * 100, 'نوێکردنەوە ' + Math.round(p * 100) + '%'); });
      KZ.progress(-1);
      if (r.ok) { KZ.toast('نوێکرایەوە. ئەگەر ئامرازێک کاری نەکرد Premiere دووبارە بکەرەوە'); setTimeout(function () { location.reload(); }, 1400); }
      else KZ.toast(r.error, 'bad');
    };

    var s = refreshBadge();
    showCat('edit');
    showTab(s.state === 'locked' ? 'settings' : 'silence');

    if (KZ.version.updateUrl) KZ.updater.check().then(function (r) {
      refreshBadge();
      if (r.ok && r.newer) { pendingUpdate = r.manifest; KZ.toast('وەشانی نوێ ' + r.manifest.version + ' بەردەستە (ڕێکخستن ← نوێکردنەوە)'); $('#st-upd-go').classList.remove('hide'); $('#st-upd-msg').textContent = r.manifest.notes || ''; }
    });
    KZ.jsx('ping').then(function (p) { KZ.log(p.ok ? 'Premiere ' + p.app + (p.seq ? ' · ' + p.seq : '') : p.error); });
  }
  document.addEventListener('DOMContentLoaded', init);
})();
