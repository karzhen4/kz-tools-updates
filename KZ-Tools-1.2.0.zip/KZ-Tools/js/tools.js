/* KZ Tools — لۆجیکی ئامرازەکان */
(function () {
  'use strict';
  var KZ = window.KZ, LIB = window.KZ_LIB, fs = require('fs'), path = require('path');
  var T = KZ.tools = {};
  var busy = false;

  function needFF() {
    var ff = KZ.ffmpeg();
    if (!ff) { KZ.toast('ffmpeg نەدۆزرایەوە. لە «ڕێکخستن» دایبەزێنە', 'bad'); return null; }
    return ff;
  }
  function gate() {
    if (!KZ.license.canUse()) { KZ.toast('کۆدی مۆڵەت پێویستە', 'bad'); return false; }
    if (busy) { KZ.toast('کارێکی تر ماوە', 'bad'); return false; }
    return true;
  }
  async function guard(fn) {
    if (!gate()) return;
    busy = true;
    try { await fn(); } catch (e) { KZ.toast('هەڵە: ' + (e && e.message || e), 'bad'); KZ.log('هەڵە: ' + (e && e.message || e)); }
    busy = false; KZ.progress(-1);
  }
  async function pickClip(needPath) {
    var r = await KZ.jsx('getSelection');
    if (!r.ok) { KZ.toast(r.error, 'bad'); return null; }
    var clips = (r.clips || []).filter(function (c) { return !needPath || c.path; });
    if (!clips.length) { KZ.toast('کلیپێکی خاوەن فایل هەڵبژێرە', 'bad'); return null; }
    // دەنگ لە پێشە بۆ بێدەنگی
    return { clip: clips[0], all: clips, info: r };
  }

  // ---------- بڕینی بێدەنگی ----------
  T.silence = function () {
    return guard(async function () {
      var ff = needFF(); if (!ff) return;
      var sel = await pickClip(true); if (!sel) return;
      var c = sel.clip, dur = c.outPoint - c.inPoint;
      var db = parseFloat(KZ.$('#sl-db').value) || -35, mind = parseFloat(KZ.$('#sl-min').value) || 0.5, pad = parseFloat(KZ.$('#sl-pad').value) || 0;
      var mode = KZ.$('#sl-mode .on').getAttribute('data-v'), ripple = KZ.$('#sl-ripple').checked;
      KZ.log('پشکنینی دەنگ: ' + c.name); KZ.progress(15, 'ffmpeg دەنگ دەپشکنێت...');
      var r = await KZ.exec(ff, ['-hide_banner', '-nostats', '-ss', String(c.inPoint), '-t', String(dur), '-i', c.path, '-vn', '-af', 'silencedetect=noise=' + db + 'dB:d=' + mind, '-f', 'null', '-']);
      if (r.code !== 0 && r.err.indexOf('silence_') < 0) { KZ.toast('ffmpeg سەرکەوتوو نەبوو', 'bad'); KZ.log(r.err.slice(-300)); return; }
      var sil = LIB.parseSilence(r.err, dur);
      var ranges = LIB.toSeqRanges(sil, c.start, dur, pad, 0.1);
      if (!ranges.length) { KZ.toast('هیچ بێدەنگییەک نەدۆزرایەوە'); return; }
      var tot = LIB.totalLen(ranges);
      KZ.log('دۆزرایەوە: ' + ranges.length + ' بێدەنگی، کۆی ' + KZ.fmt(tot));
      KZ.progress(70, 'لە Premiere جێبەجێ دەکرێت...');
      var out;
      if (mode === 'mark') {
        out = await KZ.jsx('addMarkers', { ranges: ranges.map(function (x) { return { s: x.s, e: x.e, name: 'بێدەنگی' }; }), color: 4 });
        if (out.ok) KZ.toast(out.count + ' نیشانە دانرا (' + KZ.fmt(tot) + ' بێدەنگی)');
      } else {
        out = await KZ.jsx('cutRanges', { ranges: ranges, ripple: ripple, pkind: c.kind, ptrack: c.track });
        if (out.ok) KZ.toast(out.removed + ' پارچە لابرا (' + KZ.fmt(tot) + ')');
      }
      if (!out.ok) { KZ.toast(out.error, 'bad'); KZ.log(out.error); }
    });
  };

  // ---------- کاپشن ----------
  var MODEL_URL = 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-';
  async function ensureModel(name) {
    var dir = path.join(KZ.dataDir, 'models'); try { fs.mkdirSync(dir); } catch (e) {}
    var p = path.join(dir, 'ggml-' + name + '.bin');
    if (fs.existsSync(p) && fs.statSync(p).size > 1000000) return p;
    KZ.log('دابەزاندنی مۆدێلی ' + name + ' (تەنها یەکجار)...');
    var tmp = p + '.part';
    await KZ.download(MODEL_URL + name + '.bin', tmp, function (x) { KZ.progress(x * 40, 'دابەزاندنی مۆدێل ' + Math.round(x * 100) + '%'); });
    fs.renameSync(tmp, p);
    return p;
  }
  T.caption = function () {
    return guard(async function () {
      var ff = needFF(); if (!ff) return;
      var wh = KZ.whisper();
      if (!wh) { KZ.toast('whisper نەدۆزرایەوە. لە ترمیناڵ: brew install whisper-cpp', 'bad'); return; }
      var sel = await pickClip(true); if (!sel) return;
      var c = sel.clip, dur = c.outPoint - c.inPoint;
      var lang = KZ.$('#cp-lang').value, model = KZ.$('#cp-model').value, len = parseInt(KZ.$('#cp-len').value, 10) || 38;
      var mp = await ensureModel(model);
      var base = LIB.safeName(c.name) + '_' + Date.now(), wav = KZ.tmp(base + '.wav');
      KZ.progress(45, 'دەرهێنانی دەنگ...');
      var r = await KZ.exec(ff, ['-y', '-hide_banner', '-ss', String(c.inPoint), '-t', String(dur), '-i', c.path, '-vn', '-ac', '1', '-ar', '16000', '-c:a', 'pcm_s16le', wav]);
      if (r.code !== 0) { KZ.toast('دەرهێنانی دەنگ سەرکەوتوو نەبوو', 'bad'); KZ.log(r.err.slice(-300)); return; }
      KZ.progress(55, 'گۆڕین بۆ نووسین (کاتی دەوێت)...');
      var outBase = path.join(KZ.workDir(), base);
      r = await KZ.exec(wh, ['-m', mp, '-f', wav, '-l', lang, '-osrt', '-of', outBase, '-ml', String(len), '-sow']);
      var srt = outBase + '.srt';
      if (!fs.existsSync(srt)) { KZ.toast('کاپشن دروست نەبوو', 'bad'); KZ.log((r.err || r.out).slice(-400)); return; }
      KZ.progress(90, 'هاوردەکردن بۆ Premiere...');
      var out = await KZ.jsx('importCaptions', { path: srt, at: c.start });
      try { fs.unlinkSync(wav); } catch (e) {}
      if (!out.ok) { KZ.toast(out.error, 'bad'); return; }
      KZ.toast(out.track ? 'کاپشن لەسەر تایم‌لاین دانرا' : 'SRT هاوردەکرا. لە پڕۆژە بیکێشە بۆ تایم‌لاین');
      KZ.log('SRT: ' + srt); KZ.setSetting('lastSrt', srt);
    });
  };
  T.importSrt = function () {
    return guard(async function () {
      var f = KZ.pickFile('SRT', ['srt']); if (!f) return;
      var sel = await KZ.jsx('getSelection');
      var at = (sel.ok && sel.clips && sel.clips[0]) ? sel.clips[0].start : (sel.ok ? sel.playhead : 0);
      var out = await KZ.jsx('importCaptions', { path: f, at: at });
      if (!out.ok) { KZ.toast(out.error, 'bad'); return; }
      KZ.toast(out.track ? 'کاپشن دانرا' : 'SRT هاوردەکرا');
    });
  };

  // ---------- دەنگ ----------
  var FILTERS = {
    voice: 'highpass=f=90,lowpass=f=12000,afftdn=nf=-25,acompressor=threshold=-18dB:ratio=3:attack=5:release=80,loudnorm=I=-16:TP=-1.5:LRA=11',
    noise: 'highpass=f=80,afftdn=nf=-25',
    norm: 'loudnorm=I=-16:TP=-1.5:LRA=11'
  };
  T.audio = function () {
    return guard(async function () {
      var ff = needFF(); if (!ff) return;
      var sel = await pickClip(true); if (!sel) return;
      var c = sel.clip, dur = c.outPoint - c.inPoint, preset = KZ.$('#au-preset').value, tr = (parseInt(KZ.$('#au-track').value, 10) || 2) - 1;
      var out = path.join(KZ.workDir(), LIB.safeName(c.name) + '_clean_' + Date.now() + '.wav');
      KZ.progress(30, 'ffmpeg دەنگ پاک دەکاتەوە...');
      var r = await KZ.exec(ff, ['-y', '-hide_banner', '-ss', String(c.inPoint), '-t', String(dur), '-i', c.path, '-vn', '-af', FILTERS[preset], '-ar', '48000', '-c:a', 'pcm_s16le', out]);
      if (r.code !== 0) { KZ.toast('پاککردنەوە سەرکەوتوو نەبوو', 'bad'); KZ.log(r.err.slice(-300)); return; }
      KZ.progress(80, 'هاوردەکردن...');
      var im = await KZ.jsx('importFile', { path: out });
      if (!im.ok) { KZ.toast('هاوردەکردن سەرکەوتوو نەبوو', 'bad'); return; }
      var pl = await KZ.jsx('placeAudio', { path: out, track: tr, at: c.start });
      if (!pl.ok) { KZ.toast('فایل هاوردەکرا، بەڵام دانان نەکرا: ' + pl.error, 'bad'); return; }
      KZ.toast('دەنگی پاککراوە لەسەر A' + (tr + 1) + ' دانرا');
    });
  };

  // ---------- زووم ----------
  T.zoom = function () {
    return guard(async function () {
      var out = await KZ.jsx('zoomClips', {
        mode: KZ.$('#zm-mode .on').getAttribute('data-v'), amount: parseFloat(KZ.$('#zm-amt').value) || 115,
        duration: parseFloat(KZ.$('#zm-dur').value) || 2, where: KZ.$('#zm-where').value
      });
      if (!out.ok) { KZ.toast(out.error, 'bad'); return; }
      KZ.toast(out.count ? 'کیفرەیم بۆ ' + out.count + ' کلیپ دانرا' : 'هیچ کلیپێکی ڤیدیۆ هەڵنەبژێردرابوو', out.count ? '' : 'bad');
    });
  };

  // ---------- موگرت ----------
  var mgSel = null;
  function scan(dir, acc, depth) {
    if (depth > 4) return acc;
    var ents; try { ents = fs.readdirSync(dir); } catch (e) { return acc; }
    ents.forEach(function (n) {
      var p = path.join(dir, n), st; try { st = fs.statSync(p); } catch (e) { return; }
      if (st.isDirectory()) scan(p, acc, depth + 1); else if (/\.mogrt$/i.test(n)) acc.push({ name: n.replace(/\.mogrt$/i, ''), path: p });
    });
    return acc;
  }
  T.mogrtLoad = function () {
    var dir = KZ.$('#mg-folder').value.trim(), box = KZ.$('#mg-list'); mgSel = null;
    box.innerHTML = '';
    if (!dir || !fs.existsSync(dir)) { box.innerHTML = '<div class="empty">فۆڵدەرێک هەڵبژێرە</div>'; return; }
    KZ.setSetting('mogrtDir', dir);
    var list = scan(dir, [], 0);
    if (!list.length) { box.innerHTML = '<div class="empty">هیچ .mogrt ێک نەدۆزرایەوە</div>'; return; }
    list.forEach(function (it) {
      var d = document.createElement('div'); d.textContent = it.name;
      d.onclick = function () { KZ.$$('#mg-list div').forEach(function (x) { x.classList.remove('on'); }); d.classList.add('on'); mgSel = it; };
      box.appendChild(d);
    });
  };
  T.mogrtInsert = function () {
    return guard(async function () {
      if (!mgSel) { KZ.toast('موگرتێک هەڵبژێرە', 'bad'); return; }
      var out = await KZ.jsx('insertMogrt', { path: mgSel.path, useCTI: true, vtrack: (parseInt(KZ.$('#mg-vt').value, 10) || 2) - 1, atrack: 0 });
      if (!out.ok) { KZ.toast(out.error || 'دانان سەرکەوتوو نەبوو', 'bad'); return; }
      KZ.toast('دانرا: ' + mgSel.name);
    });
  };

  // ---------- ئامرازە خێراکان ----------
  T.markHere = function () {
    return guard(async function () {
      var s = await KZ.jsx('getSelection'); if (!s.ok) { KZ.toast(s.error, 'bad'); return; }
      var out = await KZ.jsx('addMarkers', { ranges: [{ s: s.playhead, e: s.playhead, name: KZ.$('#tl-mname').value || 'KZ' }], color: 4 });
      KZ.toast(out.ok ? 'نیشانە دانرا' : out.error, out.ok ? '' : 'bad');
    });
  };
  T.markEvery = function () {
    return guard(async function () {
      var s = await KZ.jsx('getSelection'); if (!s.ok) { KZ.toast(s.error, 'bad'); return; }
      if (!s.clips.length) { KZ.toast('کلیپێک هەڵبژێرە', 'bad'); return; }
      var a = Infinity, b = 0; s.clips.forEach(function (c) { a = Math.min(a, c.start); b = Math.max(b, c.end); });
      var out = await KZ.jsx('markersEvery', { start: a, end: b, interval: parseFloat(KZ.$('#tl-int').value) || 5, name: KZ.$('#tl-mname').value || 'KZ' });
      KZ.toast(out.ok ? out.count + ' نیشانە دانرا' : out.error, out.ok ? '' : 'bad');
    });
  };
  T.markClear = function () {
    return guard(async function () {
      var out = await KZ.jsx('clearMarkers');
      KZ.toast(out.ok ? out.count + ' نیشانە سڕایەوە' : out.error, out.ok ? '' : 'bad');
    });
  };
  T.organize = function () {
    return guard(async function () {
      var out = await KZ.jsx('organize');
      KZ.toast(out.ok ? out.moved + ' فایل ڕێکخرا' : out.error, out.ok ? '' : 'bad');
    });
  };


  // ---------- ژێرنووس ئێدیتۆر ----------
  function srtLoad(f) {
    try { KZ.$('#sr-text').value = fs.readFileSync(f, 'utf8'); KZ.$('#sr-path').textContent = f; }
    catch (e) { KZ.toast('فایلەکە نەخوێنرایەوە', 'bad'); }
  }
  T.srtOpen = function () { var f = KZ.pickFile('SRT', ['srt']); if (f) srtLoad(f); };
  T.srtLast = function () {
    var f = KZ.getSetting('lastSrt', '');
    if (f && fs.existsSync(f)) srtLoad(f); else KZ.toast('هێشتا کاپشنێک دروست نەکراوە', 'bad');
  };
  function srtItems() {
    var it = LIB.parseSrt(KZ.$('#sr-text').value);
    if (!it.length) KZ.toast('ناوەڕۆکی SRT دروست نییە', 'bad');
    return it;
  }
  T.srtFix = function () { var t = KZ.$('#sr-text'); t.value = LIB.normalizeKurdish(t.value); KZ.toast('پیتەکان ڕاستکرانەوە (ي ك ة ← ی ک ە)'); };
  T.srtWrap = function () {
    var it = srtItems(); if (!it.length) return;
    var n = parseInt(KZ.$('#sr-wrap').value, 10) || 32;
    it.forEach(function (x) { x.text = LIB.wrapLines(x.text, n); });
    KZ.$('#sr-text').value = LIB.buildSrt(it);
  };
  T.srtShift = function () {
    var it = srtItems(); if (!it.length) return;
    KZ.$('#sr-text').value = LIB.buildSrt(LIB.shiftSrt(it, parseFloat(KZ.$('#sr-shift').value) || 0));
  };
  T.srtSave = function () {
    return guard(async function () {
      var it = srtItems(); if (!it.length) return;
      var f = path.join(KZ.workDir(), 'edited_' + Date.now() + '.srt');
      fs.writeFileSync(f, LIB.buildSrt(it), 'utf8');
      var sel = await KZ.jsx('getSelection');
      var at = (sel.ok && sel.clips && sel.clips[0]) ? sel.clips[0].start : (sel.ok ? sel.playhead : 0);
      var out = await KZ.jsx('importCaptions', { path: f, at: at });
      if (!out.ok) { KZ.toast(out.error, 'bad'); return; }
      KZ.toast(out.track ? 'کاپشنی نوێ دانرا' : 'SRT هاوردەکرا. لە پڕۆژە بیکێشە بۆ تایم‌لاین');
    });
  };

  // ---------- لاوەر سێرد ----------
  T.lowerPlace = function () {
    return guard(async function () {
      var png = KZ.lower.save();
      var s = await KZ.jsx('getSelection'); if (!s.ok) { KZ.toast(s.error, 'bad'); return; }
      var out = await KZ.jsx('placeImage', { path: png, at: s.playhead, track: (parseInt(KZ.$('#lt-vt').value, 10) || 3) - 1, duration: parseFloat(KZ.$('#lt-dur').value) || 5 });
      if (!out.ok) { KZ.toast(out.error, 'bad'); return; }
      KZ.toast(out.durationSet ? 'لاوەر سێرد دانرا' : 'دانرا، بەڵام ماوەکەی بە دەست ڕاست بکەرەوە (5 چرکەی بنەڕەت)');
    });
  };
  T.lowerSave = function () {
    try { var p = KZ.lower.save(); KZ.toast('PNG هەڵگیرا'); KZ.log(p); } catch (e) { KZ.toast('هەڵگرتن سەرکەوتوو نەبوو', 'bad'); }
  };

  // ---------- گۆڕینی فۆرمات ----------
  var convSrc = '', convChild = null;
  T.convPick = function () {
    var f = KZ.pickFile('فایل', []); if (!f) { KZ.toast('فایلەکە هەڵنەبژێردرا', 'bad'); return; }
    convSrc = f; KZ.$('#cv-src').textContent = path.basename(f);
  };
  T.convClear = function () { convSrc = ''; KZ.$('#cv-src').textContent = 'کلیپی هەڵبژێردراوی تایم‌لاین'; };
  T.convCancel = function () { if (convChild) { try { convChild.kill(); } catch (e) {} } };
  T.convert = function () {
    return guard(async function () {
      var ff = needFF(); if (!ff) return;
      var src = convSrc;
      if (!src) { var sel = await pickClip(true); if (!sel) return; src = sel.clip.path; }
      var preset = KZ.$('#cv-preset').value, spec = LIB.CONVERT[preset];
      var out = path.join(KZ.workDir(), LIB.safeName(path.basename(src).replace(/\.[^.]+$/, '')) + '_' + preset + '_' + Date.now() + '.' + spec.ext);
      var total = 0, buf = '';
      KZ.$('#cv-cancel').classList.remove('hide');
      KZ.progress(1, 'دەستپێکرد...');
      var r = await KZ.exec(ff, ['-y', '-hide_banner', '-i', src].concat(spec.args, [out]), {
        onChild: function (c) { convChild = c; },
        onErr: function (d) {
          buf = (buf + d).slice(-4000);
          if (!total) total = LIB.parseDuration(buf);
          var t = LIB.parseTime(d);
          if (total && t >= 0) KZ.progress(Math.min(99, t / total * 100), 'گۆڕین ' + Math.round(t / total * 100) + '%');
        }
      });
      convChild = null; KZ.$('#cv-cancel').classList.add('hide');
      if (r.code !== 0) { KZ.toast(r.code === null || r.code === 255 ? 'وەستێنرا' : 'گۆڕین سەرکەوتوو نەبوو', 'bad'); KZ.log(buf.slice(-300)); try { fs.unlinkSync(out); } catch (e) {} return; }
      KZ.log('دەرچوو: ' + out);
      if (KZ.$('#cv-import').checked) { var im = await KZ.jsx('importFile', { path: out }); KZ.toast(im.ok ? 'تەواو بوو و هاوردەکرا' : 'تەواو بوو: ' + out); }
      else KZ.toast('تەواو بوو');
    });
  };

  // ---------- هەڵبژاردنی فایل/فۆڵدەر ----------
  KZ.pickFolder = function (title) {
    try { var r = window.cep.fs.showOpenDialog(false, true, title || 'فۆڵدەر', ''); if (r && r.data && r.data[0]) return r.data[0]; } catch (e) {}
    return null;
  };
  KZ.pickFile = function (title, exts) {
    try { var r = window.cep.fs.showOpenDialog(false, false, title || 'فایل', '', exts || []); if (r && r.data && r.data[0]) return r.data[0]; } catch (e) {}
    return null;
  };

  // ---------- دابەزاندنی ffmpeg (ماک) ----------
  T.getFfmpeg = async function () {
    if (KZ.isWin) { KZ.toast('لە ویندۆز ffmpeg.exe بخە ناو ' + path.join(KZ.dataDir, 'bin')); return; }
    var arch = require('os').arch() === 'arm64' ? 'arm64' : 'amd64';
    var bin = path.join(KZ.dataDir, 'bin'); try { fs.mkdirSync(bin); } catch (e) {}
    var zip = KZ.tmp('ffmpeg.zip');
    try {
      KZ.log('دابەزاندنی ffmpeg...');
      await KZ.download('https://ffmpeg.martin-riedl.de/redirect/latest/macos/' + arch + '/release/ffmpeg.zip', zip, function (p) { KZ.progress(p * 100, 'ffmpeg ' + Math.round(p * 100) + '%'); });
      var r = await KZ.exec('unzip', ['-o', '-q', zip, '-d', bin]);
      if (r.code !== 0) throw new Error(r.err);
      await KZ.exec('chmod', ['+x', path.join(bin, 'ffmpeg')]);
      await KZ.exec('xattr', ['-d', 'com.apple.quarantine', path.join(bin, 'ffmpeg')]);
      KZ.toast('ffmpeg دابەزی');
    } catch (e) { KZ.toast('دابەزاندن سەرکەوتوو نەبوو. بە brew install ffmpeg تاقی بکەرەوە', 'bad'); KZ.log(String(e.message || e)); }
    KZ.progress(-1);
  };
})();
