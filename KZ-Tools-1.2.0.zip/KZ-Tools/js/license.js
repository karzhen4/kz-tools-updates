/* KZ Tools — سیستەمی لایسنس (ئیمزای ECDSA P-256). تەنها خاوەنی private.pem دەتوانێت کۆد دروست بکات. */
(function () {
  'use strict';
  var KZ = window.KZ, fs = require('fs'), path = require('path'), os = require('os'), crypto = require('crypto'), cp = require('child_process');
  var L = KZ.license = {};
  var licFile = path.join(KZ.dataDir, 'license.txt');
  var trialFile = path.join(KZ.dataDir, 'trial.json');
  var revokedFile = path.join(KZ.dataDir, 'revoked.json');

  function b64uDecode(s) { s = s.replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; return Buffer.from(s, 'base64'); }

  // ناسنامەی ئامێر
  L.deviceId = function () {
    if (L._dev) return L._dev;
    var raw = '';
    try {
      if (process.platform === 'darwin') {
        var o = cp.execSync('ioreg -rd1 -c IOPlatformExpertDevice', { encoding: 'utf8', env: KZ.env() });
        var m = /"IOPlatformUUID" = "([^"]+)"/.exec(o); if (m) raw = m[1];
      } else if (KZ.isWin) {
        var w = cp.execSync('reg query HKLM\\SOFTWARE\\Microsoft\\Cryptography /v MachineGuid', { encoding: 'utf8' });
        var mw = /MachineGuid\s+REG_SZ\s+(\S+)/.exec(w); if (mw) raw = mw[1];
      }
    } catch (e) {}
    if (!raw) raw = os.hostname() + '|' + os.userInfo().username;
    var h = crypto.createHash('sha256').update('kz|' + raw).digest('hex').toUpperCase().slice(0, 12);
    L._dev = h.slice(0, 4) + '-' + h.slice(4, 8) + '-' + h.slice(8, 12);
    return L._dev;
  };

  // پشکنینی کۆد
  L.verify = function (code) {
    code = String(code || '').replace(/\s+/g, '');
    if (code.indexOf('KZ1-') !== 0) return { ok: false, error: 'فۆرماتی کۆد هەڵەیە' };
    var parts = code.slice(4).split('.');
    if (parts.length !== 2) return { ok: false, error: 'فۆرماتی کۆد هەڵەیە' };
    var pub;
    try { pub = fs.readFileSync(path.join(KZ.extDir, 'license.pub'), 'utf8'); } catch (e) { return { ok: false, error: 'فایلی license.pub نەدۆزرایەوە' }; }
    var good = false;
    try { good = crypto.createVerify('SHA256').update(parts[0]).verify(pub, b64uDecode(parts[1])); } catch (e) { good = false; }
    if (!good) return { ok: false, error: 'کۆدەکە دروست نییە' };
    var p;
    try { p = JSON.parse(b64uDecode(parts[0]).toString('utf8')); } catch (e) { return { ok: false, error: 'کۆدەکە تێکچووە' }; }
    if (p.d !== '*' && p.d !== L.deviceId()) return { ok: false, error: 'ئەم کۆدە بۆ ئامێرێکی دیکەیە' };
    if (p.e && new Date(p.e + 'T23:59:59') < new Date()) return { ok: false, error: 'کۆدەکە بەسەرچووە (' + p.e + ')' };
    var rev = L.revoked();
    if (rev.indexOf(p.i) >= 0) return { ok: false, error: 'ئەم کۆدە هەڵوەشێنراوەتەوە' };
    return { ok: true, info: p };
  };
  L.revoked = function () { try { return JSON.parse(fs.readFileSync(revokedFile, 'utf8')); } catch (e) { return []; } };
  L.setRevoked = function (list) { try { fs.writeFileSync(revokedFile, JSON.stringify(list || [])); } catch (e) {} };

  L.activate = function (code) {
    var r = L.verify(code);
    if (r.ok) { try { fs.writeFileSync(licFile, String(code).replace(/\s+/g, '')); } catch (e) { return { ok: false, error: 'نەتوانرا هەڵبگیرێت' }; } }
    return r;
  };
  L.deactivate = function () { try { fs.unlinkSync(licFile); } catch (e) {} };

  // تاقیکردنەوە
  function trialStart() {
    var t = null;
    try { t = JSON.parse(fs.readFileSync(trialFile, 'utf8')).start; } catch (e) {}
    try { var ls = window.localStorage.getItem('kz_trial'); if (ls && (!t || +ls < t)) t = +ls; } catch (e) {}
    if (!t) t = Date.now();
    try { fs.writeFileSync(trialFile, JSON.stringify({ start: t })); } catch (e) {}
    try { window.localStorage.setItem('kz_trial', String(t)); } catch (e) {}
    return t;
  }
  L.trialLeftDays = function () {
    var days = KZ.version.trialDays || 0;
    if (!days) return 0;
    var left = days - (Date.now() - trialStart()) / 86400000;
    return Math.max(0, left);
  };

  // دۆخی گشتی: {state:'licensed'|'trial'|'locked', ...}
  L.status = function () {
    var code = ''; try { code = fs.readFileSync(licFile, 'utf8'); } catch (e) {}
    if (code) {
      var r = L.verify(code);
      if (r.ok) return { state: 'licensed', info: r.info };
      var tl0 = L.trialLeftDays();
      return { state: tl0 > 0 ? 'trial' : 'locked', error: r.error, days: tl0 };
    }
    var tl = L.trialLeftDays();
    return tl > 0 ? { state: 'trial', days: tl } : { state: 'locked' };
  };
  L.canUse = function () { var s = L.status(); return s.state === 'licensed' || s.state === 'trial'; };
})();
