/* KZ Tools — ExtendScript (Premiere Pro). ES3 تەنها: بێ JSON، بێ let/const */
var KZ_HOST = (function () {
  var TICKS = 254016000000;

  function esc(s) { return String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n').replace(/\r/g, '\\r').replace(/\t/g, '\\t'); }
  function J(v) {
    var t = typeof v, i, out;
    if (v === null || v === undefined) return 'null';
    if (t === 'number') return isFinite(v) ? String(v) : 'null';
    if (t === 'boolean') return v ? 'true' : 'false';
    if (t === 'string') return '"' + esc(v) + '"';
    if (v instanceof Array) { out = []; for (i = 0; i < v.length; i++) out.push(J(v[i])); return '[' + out.join(',') + ']'; }
    out = []; for (i in v) if (v.hasOwnProperty(i)) out.push('"' + esc(i) + '":' + J(v[i]));
    return '{' + out.join(',') + '}';
  }
  function P(s) { return eval('(' + s + ')'); }
  function fail(e) { return J({ ok: false, error: String(e && e.message ? e.message : e) }); }
  function seqOrThrow() {
    if (!app.project) throw 'هیچ پڕۆژەیەک کراوە نییە';
    var s = app.project.activeSequence;
    if (!s) throw 'سیکوەنسێکی چالاک نییە، سیکوەنسێک بکەرەوە';
    return s;
  }
  function fps(seq) { return TICKS / Number(seq.timebase); }
  function tcOf(sec, seq) {
    var f = fps(seq), r = Math.round(f), total = Math.round(sec * f);
    var ff = total % r, s = Math.floor(total / r), ss = s % 60, mm = Math.floor(s / 60) % 60, hh = Math.floor(s / 3600);
    function z(n) { return (n < 10 ? '0' : '') + n; }
    return z(hh) + ':' + z(mm) + ':' + z(ss) + ':' + z(ff);
  }
  function mkTime(sec) { var t = new Time(); t.seconds = sec; return t; }
  function clipInfo(c, kind, idx) {
    var path = '';
    try { path = c.projectItem ? c.projectItem.getMediaPath() : ''; } catch (e) {}
    return { name: c.name, path: path, start: c.start.seconds, end: c.end.seconds, inPoint: c.inPoint.seconds, outPoint: c.outPoint.seconds, kind: kind, track: idx };
  }
  function eachTrack(seq, fn) {
    var i, j, tr;
    for (i = 0; i < seq.videoTracks.numTracks; i++) { tr = seq.videoTracks[i]; for (j = 0; j < tr.clips.numItems; j++) fn(tr.clips[j], 'video', i, tr); }
    for (i = 0; i < seq.audioTracks.numTracks; i++) { tr = seq.audioTracks[i]; for (j = 0; j < tr.clips.numItems; j++) fn(tr.clips[j], 'audio', i, tr); }
  }
  function findItem(parent, name) {
    var i, c, r;
    for (i = 0; i < parent.children.numItems; i++) {
      c = parent.children[i];
      if (c.name === name) return c;
      if (c.type === 2) { r = findItem(c, name); if (r) return r; }
    }
    return null;
  }
  function baseName(p) { return String(p).replace(/^.*[\\\/]/, ''); }

  var H = {};

  H.ping = function () {
    try {
      var seq = app.project ? app.project.activeSequence : null;
      return J({ ok: true, app: app.version, seq: seq ? seq.name : null, fps: seq ? fps(seq) : 0 });
    } catch (e) { return fail(e); }
  };

  H.getSelection = function () {
    try {
      var seq = seqOrThrow(), sel = seq.getSelection(), out = [], i, c, kind, idx, found;
      for (i = 0; i < sel.length; i++) {
        c = sel[i]; kind = 'video'; idx = 0; found = false;
        eachTrack(seq, function (cc, k, ti) { if (!found && cc.nodeId === c.nodeId) { kind = k; idx = ti; found = true; } });
        out.push(clipInfo(c, kind, idx));
      }
      return J({ ok: true, clips: out, playhead: seq.getPlayerPosition().seconds, seqEnd: Number(seq.end) / TICKS, fps: fps(seq), tracks: { v: seq.videoTracks.numTracks, a: seq.audioTracks.numTracks } });
    } catch (e) { return fail(e); }
  };

  // ---------- نیشانەکان ----------
  H.addMarkers = function (s) {
    try {
      var a = P(s), seq = seqOrThrow(), i, m;
      for (i = 0; i < a.ranges.length; i++) {
        m = seq.markers.createMarker(a.ranges[i].s);
        m.name = a.ranges[i].name || 'KZ';
        try { m.end = mkTime(a.ranges[i].e); } catch (e1) {}
        try { m.setColorByIndex(a.color === undefined ? 4 : a.color); } catch (e2) {}
      }
      return J({ ok: true, count: a.ranges.length });
    } catch (e) { return fail(e); }
  };
  H.markersEvery = function (s) {
    try {
      var a = P(s), seq = seqOrThrow(), n = 0, t, end = a.end, m;
      for (t = a.start; t < end - 0.001; t += a.interval) { m = seq.markers.createMarker(t); m.name = a.name || 'KZ'; n++; }
      return J({ ok: true, count: n });
    } catch (e) { return fail(e); }
  };
  H.clearMarkers = function () {
    try {
      var seq = seqOrThrow(), n = 0, m;
      while ((m = seq.markers.getFirstMarker())) { seq.markers.deleteMarker(m); n++; if (n > 5000) break; }
      return J({ ok: true, count: n });
    } catch (e) { return fail(e); }
  };

  // ---------- بڕینی بێدەنگی ----------
  H.cutRanges = function (s) {
    try {
      var a = P(s), seq = seqOrThrow(), r = a.ranges, i, j, k, eps = 0.02;
      if (!r || !r.length) return J({ ok: true, removed: 0 });
      r.sort(function (x, y) { return x.s - y.s; });
      app.enableQE();
      var q = qe.project.getActiveSequence(), nv = seq.videoTracks.numTracks, na = seq.audioTracks.numTracks, tc;
      // 1) razor لە هەموو هێڵەکان
      for (i = 0; i < r.length; i++) {
        for (k = 0; k < 2; k++) {
          tc = tcOf(k === 0 ? r[i].s : r[i].e, seq);
          for (j = 0; j < nv; j++) { try { q.getVideoTrackAt(j).razor(tc); } catch (e1) {} }
          for (j = 0; j < na; j++) { try { q.getAudioTrackAt(j).razor(tc); } catch (e2) {} }
        }
      }
      // 2) لابردن لە کۆتاییەوە بۆ سەرەتا
      var removed = 0;
      for (i = r.length - 1; i >= 0; i--) {
        var items = [];
        eachTrack(seq, function (c, kind, ti) {
          if (c.start.seconds >= r[i].s - eps && c.end.seconds <= r[i].e + eps) items.push({ c: c, kind: kind, ti: ti });
        });
        var primary = null, rest = [];
        for (j = 0; j < items.length; j++) {
          if (a.ripple && items[j].kind === a.pkind && items[j].ti === a.ptrack) primary = items[j]; else rest.push(items[j]);
        }
        for (j = 0; j < rest.length; j++) { try { rest[j].c.remove(false, false); removed++; } catch (e3) {} }
        if (primary) { try { primary.c.remove(true, true); removed++; } catch (e4) {} }
        else if (a.ripple && items.length) { /* هێڵی سەرەکی نەدۆزرایەوە: بەبێ ڕیپڵ */ }
      }
      return J({ ok: true, removed: removed });
    } catch (e) { return fail(e); }
  };

  // ---------- زووم ----------
  function findProp(clip, compMatch, propMatch) {
    var i, j, comp, pr;
    for (i = 0; i < clip.components.numItems; i++) {
      comp = clip.components[i];
      if (comp.matchName === compMatch) {
        for (j = 0; j < comp.properties.numItems; j++) { pr = comp.properties[j]; if (pr.matchName === propMatch) return pr; }
      }
    }
    return null;
  }
  H.zoomClips = function (s) {
    try {
      var a = P(s), seq = seqOrThrow(), sel = seq.getSelection(), i, n = 0, c, sc, dur, base, t0, t1, from, to;
      if (!sel.length) throw 'کلیپێک هەڵبژێرە';
      for (i = 0; i < sel.length; i++) {
        c = sel[i];
        if (c.mediaType !== 'Video') continue;
        sc = findProp(c, 'AE.ADBE Motion', 'ADBE Scale'); if (!sc) continue;
        var clipDur = c.end.seconds - c.start.seconds;
        dur = Math.min(a.duration, clipDur);
        base = c.inPoint.seconds;
        if (a.where === 'end') t0 = base + clipDur - dur; else t0 = base;
        t1 = t0 + dur;
        if (a.mode === 'out') { from = a.amount; to = 100; } else { from = 100; to = a.amount; }
        if (a.mode === 'punch') { from = a.amount; to = a.amount; t0 = base; t1 = base + clipDur; }
        sc.setTimeVarying(true);
        sc.addKey(t0); sc.setValueAtKey(t0, from, 1);
        sc.addKey(t1); sc.setValueAtKey(t1, to, 1);
        n++;
      }
      return J({ ok: true, count: n });
    } catch (e) { return fail(e); }
  };

  // ---------- هاوردە و دانان ----------
  H.importFile = function (s) {
    try {
      var a = P(s), ok = app.project.importFiles([a.path], true, app.project.getInsertionBin(), false);
      return J({ ok: !!ok });
    } catch (e) { return fail(e); }
  };
  H.placeAudio = function (s) {
    try {
      var a = P(s), seq = seqOrThrow(), it = findItem(app.project.rootItem, baseName(a.path));
      if (!it) throw 'فایلی هاوردەکراو نەدۆزرایەوە';
      var tr = seq.audioTracks[a.track];
      if (!tr) throw 'هێڵی دەنگ نییە';
      tr.overwriteClip(it, mkTime(a.at));
      return J({ ok: true });
    } catch (e) { return fail(e); }
  };
  H.importCaptions = function (s) {
    try {
      var a = P(s), seq = seqOrThrow();
      app.project.importFiles([a.path], true, app.project.getInsertionBin(), false);
      var it = findItem(app.project.rootItem, baseName(a.path));
      if (!it) throw 'فایلی SRT هاوردە نەکرا';
      var made = false;
      try { seq.createCaptionTrack(it, a.at, Sequence.CAPTION_FORMAT_SUBTITLE); made = true; } catch (e1) {}
      return J({ ok: true, track: made });
    } catch (e) { return fail(e); }
  };


  H.placeImage = function (s) {
    try {
      var a = P(s), seq = seqOrThrow();
      app.project.importFiles([a.path], true, app.project.getInsertionBin(), false);
      var it = findItem(app.project.rootItem, baseName(a.path));
      if (!it) throw 'وێنەکە هاوردە نەکرا';
      var tr = seq.videoTracks[a.track];
      if (!tr) throw 'هێڵی ڤیدیۆ ' + (a.track + 1) + ' نییە، سەرەتا هێڵێک زیاد بکە';
      tr.overwriteClip(it, mkTime(a.at));
      if (a.toEnd) a.duration = Math.max(1, Number(seq.end) / TICKS - a.at);
      var j, c, set = false;
      for (j = tr.clips.numItems - 1; j >= 0; j--) {
        c = tr.clips[j];
        if (Math.abs(c.start.seconds - a.at) < 0.05) { try { c.end = mkTime(a.at + a.duration); set = true; } catch (e1) {} break; }
      }
      return J({ ok: true, durationSet: set });
    } catch (e) { return fail(e); }
  };


  // ---------- دانانی ڤیدیۆ ----------
  H.placeVideo = function (s) {
    try {
      var a = P(s), seq = seqOrThrow();
      app.project.importFiles([a.path], true, app.project.getInsertionBin(), false);
      var it = findItem(app.project.rootItem, baseName(a.path));
      if (!it) throw 'فایلەکە هاوردە نەکرا';
      var tr = seq.videoTracks[a.track];
      if (!tr) throw 'هێڵی ڤیدیۆ ' + (a.track + 1) + ' نییە، سەرەتا هێڵێک زیاد بکە';
      tr.overwriteClip(it, mkTime(a.at));
      return J({ ok: true });
    } catch (e) { return fail(e); }
  };

  // ---------- ترانزیشن (QE) ----------
  function qeStart(it) {
    try { if (it.start && it.start.secs !== undefined) return Number(it.start.secs); } catch (e) {}
    try { if (it.start && it.start.ticks !== undefined) return Number(it.start.ticks) / TICKS; } catch (e2) {}
    return -1;
  }
  H.addTransitions = function (s) {
    try {
      var a = P(s), seq = seqOrThrow(), sel = seq.getSelection(), items = [], i, k, n = 0;
      if (!sel.length) throw 'کلیپەکان هەڵبژێرە';
      app.enableQE();
      var q = qe.project.getActiveSequence();
      eachTrack(seq, function (c, kind, ti) {
        if (kind !== 'video') return;
        for (var m = 0; m < sel.length; m++) if (sel[m].nodeId === c.nodeId) items.push({ c: c, ti: ti, st: c.start.seconds });
      });
      if (!items.length) throw 'هیچ کلیپێکی ڤیدیۆ هەڵنەبژێردراوە';
      items.sort(function (x, y) { return x.ti === y.ti ? x.st - y.st : x.ti - y.ti; });
      var tr = null;
      try { tr = qe.project.getVideoTransitionByName(a.name); } catch (e0) {}
      if (!tr) {
        try {
          var list = qe.project.getVideoTransitionList();
          for (i = 0; i < list.length; i++) if (String(list[i]).toLowerCase().indexOf(String(a.name).toLowerCase()) >= 0) { tr = qe.project.getVideoTransitionByName(list[i]); break; }
        } catch (e1) {}
      }
      if (!tr) throw 'ترانزیشنی «' + a.name + '» نەدۆزرایەوە (Premiere دەبێت بە ئینگلیزی بێت)';
      var tcd = tcOf(a.duration, seq), seen = {};
      for (i = 0; i < items.length; i++) {
        if (a.skipFirst && !seen[items[i].ti]) { seen[items[i].ti] = true; continue; }
        seen[items[i].ti] = true;
        var qt = q.getVideoTrackAt(items[i].ti);
        for (k = 0; k < qt.numItems; k++) {
          var qi = qt.getItemAt(k);
          if (Math.abs(qeStart(qi) - items[i].st) < 0.05) { try { qi.addTransition(tr, true, tcd); n++; } catch (e2) {} break; }
        }
      }
      return J({ ok: true, count: n });
    } catch (e) { return fail(e); }
  };

  // ---------- زووم: پەنچ لەسەر وشەکان و زووم یەک‌لەدوای‌یەک ----------
  function selVideo(seq) {
    var sel = seq.getSelection(), out = [], i;
    for (i = 0; i < sel.length; i++) if (sel[i].mediaType === 'Video') out.push(sel[i]);
    return out;
  }
  H.punchZoom = function (s) {
    try {
      var a = P(s), seq = seqOrThrow(), vs = selVideo(seq);
      if (!vs.length) throw 'کلیپی ڤیدیۆ هەڵبژێرە';
      var c = vs[0], sc = findProp(c, 'AE.ADBE Motion', 'ADBE Scale');
      if (!sc) throw 'Scale نەدۆزرایەوە';
      var base = c.inPoint.seconds, cs = c.start.seconds, ce = c.end.seconds, times = a.times.slice().sort(function (x, y) { return x - y; }), last = -999, n = 0, i, k0, atk = 0.08;
      sc.setTimeVarying(true);
      for (i = 0; i < times.length; i++) {
        if (times[i] < cs || times[i] > ce - (a.hold + 0.4)) continue;
        if (times[i] - last < a.hold + 0.45) continue;
        last = times[i]; k0 = base + (times[i] - cs);
        sc.addKey(k0); sc.setValueAtKey(k0, 100, 1);
        sc.addKey(k0 + atk); sc.setValueAtKey(k0 + atk, a.amount, 1);
        sc.addKey(k0 + atk + a.hold); sc.setValueAtKey(k0 + atk + a.hold, a.amount, 1);
        sc.addKey(k0 + atk + a.hold + 0.25); sc.setValueAtKey(k0 + atk + a.hold + 0.25, 100, 1);
        n++;
      }
      return J({ ok: true, count: n });
    } catch (e) { return fail(e); }
  };
  H.altZoom = function (s) {
    try {
      var a = P(s), seq = seqOrThrow(), vs = selVideo(seq), i, n = 0, sc;
      if (!vs.length) throw 'کلیپی ڤیدیۆ هەڵبژێرە';
      vs.sort(function (x, y) { return x.start.seconds - y.start.seconds; });
      for (i = 0; i < vs.length; i++) {
        sc = findProp(vs[i], 'AE.ADBE Motion', 'ADBE Scale'); if (!sc) continue;
        sc.setValue(i % 2 === 0 ? 100 : a.amount, true); n++;
      }
      return J({ ok: true, count: n });
    } catch (e) { return fail(e); }
  };

  // ---------- موگرت ----------
  H.insertMogrt = function (s) {
    try {
      var a = P(s), seq = seqOrThrow(), pos = a.useCTI ? seq.getPlayerPosition().ticks : String(Math.round(a.at * TICKS));
      var r = seq.importMGT(a.path, pos, a.vtrack, a.atrack === undefined ? 0 : a.atrack);
      return J({ ok: !!r });
    } catch (e) { return fail(e); }
  };

  // ---------- ڕێکخستنی پڕۆژە ----------
  H.organize = function () {
    try {
      var root = app.project.rootItem, cats = {
        'ڤیدیۆ': /\.(mp4|mov|mxf|avi|mkv|m4v|mts|webm|r3d|braw)$/i,
        'دەنگ': /\.(wav|mp3|aac|m4a|aif|aiff|flac|ogg)$/i,
        'وێنە': /\.(jpg|jpeg|png|gif|tif|tiff|psd|ai|webp|heic|svg)$/i,
        'گرافیک': /\.(mogrt|aep|prproj)$/i
      }, bins = {}, moved = 0, i, c, p, name, k, list = [];
      for (i = 0; i < root.children.numItems; i++) list.push(root.children[i]);
      function bin(n) {
        if (bins[n]) return bins[n];
        var j, ch;
        for (j = 0; j < root.children.numItems; j++) { ch = root.children[j]; if (ch.type === 2 && ch.name === n) { bins[n] = ch; return ch; } }
        bins[n] = root.createBin(n); return bins[n];
      }
      for (i = 0; i < list.length; i++) {
        c = list[i];
        if (c.type === 2) continue;
        p = ''; try { p = c.getMediaPath(); } catch (e0) {}
        name = null;
        if (!p) { name = 'سیکوەنسەکان'; }
        else for (k in cats) if (cats.hasOwnProperty(k) && cats[k].test(p)) { name = k; break; }
        if (!name) name = 'تر';
        try { c.moveBin(bin(name)); moved++; } catch (e1) {}
      }
      return J({ ok: true, moved: moved });
    } catch (e) { return fail(e); }
  };

  return H;
})();
