/* KZ Tools — فەنکشنە پاکەکانی گرووپی سێیەم: بیت، پاشخان، دابەزاندن */
(function (root) {
  'use strict';
  var L = {};
  // دۆزینەوەی بیت لە نموونەی float: وزەی پەنجەرە + باڵانسی ئاستی خۆگونجاو
  L.detectBeats = function (samples, sr, sens, minGap) {
    var win = Math.round(sr * 0.02), hop = win, n = Math.floor(samples.length / hop), e = [], i, j, s, flux = [], beats = [], last = -1e9;
    for (i = 0; i < n; i++) { s = 0; for (j = 0; j < win; j++) { var v = samples[i * hop + j] || 0; s += v * v; } e.push(Math.sqrt(s / win)); }
    for (i = 1; i < n; i++) flux.push(Math.max(0, e[i] - e[i - 1]));
    var k = Math.round(1 / 0.02), mult = 2.2 - (Math.max(1, Math.min(10, sens)) - 1) * 0.14;
    for (i = 1; i < flux.length - 1; i++) {
      var a = Math.max(0, i - k), b = Math.min(flux.length, i + k), m = 0;
      for (j = a; j < b; j++) m += flux[j]; m /= (b - a);
      var t = (i + 1) * hop / sr;
      if (flux[i] > m * mult + 1e-4 && flux[i] >= flux[i - 1] && flux[i] >= flux[i + 1] && t - last >= minGap) { beats.push(+t.toFixed(3)); last = t; }
    }
    return beats;
  };
  function hex(c) { return String(c || '#000000').replace('#', '0x'); }
  // ئارگومێنتەکانی ffmpeg بۆ پاشخان (ProRes نا، H.264 چونکە ڕەنگی تەواو و بێ ئەلفایە)
  L.bgArgs = function (o, out) {
    var w = 1920, h = 1080, d = Math.max(2, o.dur || 10), sp = Math.max(1, Math.min(10, o.spd || 3)) / 100, c1 = hex(o.c1), c2 = hex(o.c2), vf, src;
    if (o.kind === 'grid') {
      src = 'color=c=' + c1 + ':s=' + w + 'x' + h + ':r=30:d=' + d;
      vf = "drawgrid=w=96:h=96:t=2:c=" + c2 + "@0.35,drawgrid=w=24:h=24:t=1:c=" + c2 + "@0.10,format=yuv420p";
    } else if (o.kind === 'blur') {
      src = 'gradients=s=' + w + 'x' + h + ':c0=' + c1 + ':c1=' + c2 + ':c2=' + c1 + ':c3=' + c2 + ':n=4:speed=' + sp + ':d=' + d + ':r=30';
      vf = 'gblur=sigma=60,format=yuv420p';
    } else {
      src = 'gradients=s=' + w + 'x' + h + ':c0=' + c1 + ':c1=' + c2 + ':n=2:speed=' + sp + ':d=' + d + ':r=30';
      vf = 'format=yuv420p';
    }
    return ['-y', '-hide_banner', '-f', 'lavfi', '-i', src, '-vf', vf, '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', '-an', out];
  };
  // yt-dlp
  L.dlArgs = function (o, outTpl) {
    var q = parseInt(o.q, 10) || 1080;
    if (o.kind === 'a') return ['--no-playlist', '-f', 'bestaudio[ext=m4a]/bestaudio', '-x', '--audio-format', 'm4a', '-o', outTpl, '--print', 'after_move:filepath', o.url];
    return ['--no-playlist', '-f', 'bv*[height<=' + q + ']+ba/b[height<=' + q + ']', '--merge-output-format', 'mp4', '-o', outTpl, '--print', 'after_move:filepath', o.url];
  };
  L.validUrl = function (u) { return /^https?:\/\/[^\s"'`$;|&<>]+$/i.test(String(u || '').trim()); };
  if (typeof module !== 'undefined' && module.exports) module.exports = L; else root.KZ_LIB3 = L;
})(typeof window !== 'undefined' ? window : this);
