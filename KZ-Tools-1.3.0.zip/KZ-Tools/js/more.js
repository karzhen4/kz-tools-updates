/* KZ Tools — دابەزاندن، پاشخانی جوڵاو، بیت و نیشانە */
(function () {
  'use strict';
  var KZ = window.KZ, L1 = window.KZ_LIB, L3 = window.KZ_LIB3, fs = require('fs'), path = require('path'), $ = function (s) { return document.querySelector(s); };
  var busy = false;
  async function guard(fn) {
    if (!KZ.license.canUse()) { KZ.toast('کۆدی مۆڵەت پێویستە', 'bad'); return; }
    if (busy) { KZ.toast('کارێکی تر ماوە', 'bad'); return; }
    busy = true;
    try { await fn(); } catch (e) { KZ.toast('هەڵە: ' + (e && e.message || e), 'bad'); KZ.log('هەڵە: ' + (e && e.message || e)); }
    busy = false; KZ.progress(-1);
  }
  function ff() { var f = KZ.ffmpeg(); if (!f) KZ.toast('ffmpeg نەدۆزرایەوە. لە «ڕێکخستن» دایبەزێنە', 'bad'); return f; }
  function trk(id, d) { return Math.max(0, (parseInt($(id).value, 10) || d) - 1); }

  // ---- دابەزاندن ----
  async function download() {
    var url = $('#dl-url').value.trim();
    if (!L3.validUrl(url)) { KZ.toast('لینکێکی دروست بنووسە (http/https)', 'bad'); return; }
    var yt = KZ.which(['yt-dlp']);
    if (!yt) { KZ.toast('yt-dlp نەدۆزرایەوە. لە Terminal: brew install yt-dlp', 'bad'); return; }
    KZ.progress(5, 'دابەزاندن...');
    var tpl = path.join(KZ.workDir(), 'dl_' + Date.now() + '_%(title).60B.%(ext)s');
    var r = await KZ.exec(yt, L3.dlArgs({ url: url, kind: $('#dl-kind').value, q: $('#dl-q').value }, tpl));
    if (r.code !== 0) throw new Error('yt-dlp: ' + (r.err || '').slice(-200));
    var lines = (r.out || '').trim().split(/\r?\n/), file = lines[lines.length - 1];
    if (!file || !fs.existsSync(file)) throw new Error('فایلی دابەزێنراو نەدۆزرایەوە');
    var im = await KZ.jsx('importFile', { path: file });
    if (!im.ok) { KZ.toast('دابەزی بەڵام هێنان نەکرا: ' + im.error, 'bad'); KZ.log(file); return; }
    if ($('#dl-place').checked && $('#dl-kind').value === 'v') {
      var s = await KZ.jsx('getSelection');
      var rr = await KZ.jsx('placeVideo', { path: file, at: s.ok ? s.playhead : 0, track: 0 });
      if (!rr.ok) KZ.toast('دانان نەکرا: ' + rr.error, 'bad'); else KZ.toast('دابەزی و دانرا');
    } else KZ.toast('دابەزی و هێنرا ناو پڕۆژە');
  }

  // ---- پاشخان ----
  async function bg() {
    if (!ff()) return;
    var o = { kind: $('#bg-kind').value, c1: $('#bg-c1').value, c2: $('#bg-c2').value, dur: parseFloat($('#bg-dur').value) || 10, spd: parseFloat($('#bg-spd').value) || 3 };
    var out = path.join(KZ.workDir(), 'kz_bg_' + Date.now() + '.mp4');
    KZ.progress(10, 'دروستکردنی پاشخان...');
    var r = await KZ.exec(ff(), L3.bgArgs(o, out));
    if (r.code !== 0) throw new Error('ffmpeg: ' + (r.err || '').slice(-200));
    var s = await KZ.jsx('getSelection');
    var p = await KZ.jsx('placeVideo', { path: out, at: s.ok ? s.playhead : 0, track: trk('#bg-vt', 1) });
    if (!p.ok) { KZ.toast('دروست بوو بەڵام دانان نەکرا: ' + p.error, 'bad'); KZ.log(out); return; }
    KZ.toast('پاشخان دانرا');
  }

  // ---- بیت ----
  async function beats() {
    if (!ff()) return;
    var s = await KZ.jsx('getSelection');
    if (!s.ok) { KZ.toast(s.error, 'bad'); return; }
    var c = (s.clips || []).filter(function (x) { return x.path; })[0];
    if (!c) { KZ.toast('کلیپێکی خاوەن دەنگ هەڵبژێرە', 'bad'); return; }
    var raw = path.join(KZ.workDir(), 'beat_' + Date.now() + '.raw'), sr = 11025;
    KZ.progress(20, 'خوێندنەوەی دەنگ...');
    var r = await KZ.exec(ff(), ['-y', '-hide_banner', '-ss', String(c.inPoint), '-t', String(c.outPoint - c.inPoint), '-i', c.path, '-vn', '-ac', '1', '-ar', String(sr), '-f', 'f32le', raw]);
    if (r.code !== 0) throw new Error('ffmpeg: ' + (r.err || '').slice(-200));
    var buf = fs.readFileSync(raw); try { fs.unlinkSync(raw); } catch (e) {}
    var f32 = new Float32Array(buf.buffer, buf.byteOffset, Math.floor(buf.length / 4));
    var bt = L3.detectBeats(f32, sr, parseFloat($('#bt-sens').value) || 5, parseFloat($('#bt-gap').value) || 0.4);
    if (!bt.length) { KZ.toast('هیچ بیتێک نەدۆزرایەوە، هەستیاری زیاد بکە', 'bad'); return; }
    var ranges = bt.map(function (t, i) { var at = c.start + t; return { s: at, e: at, name: 'Beat ' + (i + 1) }; });
    var m = await KZ.jsx('addMarkers', { ranges: ranges, color: 4 });
    if (!m.ok) throw new Error(m.error);
    KZ.toast(bt.length + ' نیشانەی بیت دانرا');
  }

  $('#dl-go').onclick = function () { guard(download); };
  $('#bg-go').onclick = function () { guard(bg); };
  $('#bt-go').onclick = function () { guard(beats); };
})();
