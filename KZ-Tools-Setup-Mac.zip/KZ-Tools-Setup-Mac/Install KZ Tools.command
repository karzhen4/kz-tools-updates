#!/bin/bash
# KZ Tools — Mac installer (no admin rights needed)
cd "$(dirname "$0")"
SRC="$(pwd)/KZ-Tools"
ROOT="$HOME/Library/Application Support/Adobe/CEP/extensions"
DST="$ROOT/KZ-Tools"
echo ""
echo "   KZ Tools - Premiere Pro panel"
echo "   -----------------------------"
if [ ! -f "$SRC/CSXS/manifest.xml" ]; then
  echo "   Unzip everything first, then run this again."
  read -n1 -r -p "   Press any key..."; exit 1
fi
mkdir -p "$ROOT"
echo "   [1/3] Installing the panel..."
rm -rf "$DST"
cp -R "$SRC" "$DST"
xattr -dr com.apple.quarantine "$DST" 2>/dev/null
echo "   [2/3] Allowing the panel to load..."
for v in 9 10 11 12 13 14; do defaults write "com.adobe.CSXS.$v" PlayerDebugMode 1; done
echo "   [3/3] Checking tools..."
if command -v ffmpeg >/dev/null 2>&1 || [ -x /opt/homebrew/bin/ffmpeg ] || [ -x /usr/local/bin/ffmpeg ]; then
  echo "         ffmpeg: found"
else
  echo "         ffmpeg: not found (the panel can download it: Settings > Download ffmpeg)"
fi
if command -v whisper-cli >/dev/null 2>&1 || [ -x /opt/homebrew/bin/whisper-cli ] || [ -x /usr/local/bin/whisper-cli ]; then
  echo "         whisper: found"
else
  echo "         whisper: not found (only needed for captions) -> brew install whisper-cpp"
fi
echo ""
echo "   Done. Restart Premiere Pro, then: Window > Extensions > KZ Tools - Karzhen"
echo ""
read -n1 -r -p "   Press any key to close..."
