@echo off
setlocal
set "SRC=%~dp0KZ-Tools"
set "DST=%APPDATA%\Adobe\CEP\extensions\KZ-Tools"
if not exist "%SRC%\CSXS\manifest.xml" (echo Unzip everything first. & pause & exit /b 1)
echo Installing KZ Tools...
if exist "%DST%" rmdir /s /q "%DST%"
xcopy "%SRC%" "%DST%\" /E /I /Y /Q >nul
for %%v in (9 10 11 12 13 14) do reg add "HKCU\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul
echo.
echo Done. Put ffmpeg.exe in %USERPROFILE%\.kz-tools\bin if you do not have it.
echo Restart Premiere Pro, then: Window ^> Extensions ^> KZ Tools - Karzhen
pause
