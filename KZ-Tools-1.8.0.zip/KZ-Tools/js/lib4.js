/* KZ Tools — قاڵبە شووشەییەکان (کانڤاس) + ڕێکخستنی بلەر لەگەڵ ffmpeg */
(function (root) {
  'use strict';
  var L = {}, FONT = '"IBM Plex Sans Arabic","KZPlex","Geeza Pro","Segoe UI",Tahoma,sans-serif';
  L.PALETTES = [
    { n: 'سەوز', a: '#3ddc97', b: '#17a86c' }, { n: 'شین', a: '#4da3ff', b: '#7c6bff' }, { n: 'مۆر', a: '#b06bff', b: '#ff6bd6' },
    { n: 'نارەنجی', a: '#ff9a3d', b: '#ff4d6d' }, { n: 'سوور', a: '#ff4d5e', b: '#ff9a3d' }, { n: 'زێڕین', a: '#ffe08a', b: '#f2a33a' }, { n: 'سپی', a: '#ffffff', b: '#9fb8c9' }
  ];
  function cl(x) { return x < 0 ? 0 : x > 1 ? 1 : x; }
  function outC(x) { x = 1 - cl(x); return 1 - x * x * x; }
  function rgba(h, a) { h = String(h).replace('#', ''); if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2]; var n = parseInt(h, 16); return 'rgba(' + (n >> 16 & 255) + ',' + (n >> 8 & 255) + ',' + (n & 255) + ',' + a + ')'; }
  function rr(c, x, y, w, h, r) { r = Math.min(r, w / 2, h / 2); c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
  function env(t, d) { return Math.min(cl(t / 0.45), cl((d - t) / 0.35)); }
  L.wrap = function (c, text, maxW) {
    var words = String(text).split(/\s+/).filter(Boolean), lines = [], cur = '', i, t;
    for (i = 0; i < words.length; i++) { t = cur ? cur + ' ' + words[i] : words[i]; if (c.measureText(t).width > maxW && cur) { lines.push(cur); cur = words[i]; } else cur = t; }
    if (cur) lines.push(cur); return lines.slice(0, 4);
  };
  // لەرزین/دەرکەوتنی هاوبەش
  function pose(t, o) { var e = env(t, o.dur), p = outC(t / 0.55); return { a: e, dy: (1 - p) * 40, s: 0.94 + 0.06 * p }; }
  function glass(c, x, y, w, h, r, o, mask) {
    if (mask) { c.fillStyle = '#fff'; rr(c, x, y, w, h, r); c.fill(); return; }
    c.save(); c.shadowColor = 'rgba(0,0,0,0.42)'; c.shadowBlur = 40; c.shadowOffsetY = 20;
    var g = c.createLinearGradient(x, y, x + w, y + h); g.addColorStop(0, 'rgba(255,255,255,0.26)'); g.addColorStop(0.55, 'rgba(255,255,255,0.05)'); g.addColorStop(1, 'rgba(255,255,255,0.14)');
    c.fillStyle = g; rr(c, x, y, w, h, r); c.fill(); c.restore();
    c.save(); rr(c, x, y, w, h, r); c.clip();
    var r1 = c.createRadialGradient(x + w * 0.1, y + h * 0.05, 0, x + w * 0.1, y + h * 0.05, Math.max(w, h) * 0.45); r1.addColorStop(0, 'rgba(255,255,255,0.38)'); r1.addColorStop(1, 'rgba(255,255,255,0)'); c.fillStyle = r1; c.fillRect(x, y, w, h);
    var r2 = c.createRadialGradient(x + w * 0.95, y + h * 0.97, 0, x + w * 0.95, y + h * 0.97, Math.max(w, h) * 0.3); r2.addColorStop(0, 'rgba(255,255,255,0.28)'); r2.addColorStop(1, 'rgba(255,255,255,0)'); c.fillStyle = r2; c.fillRect(x, y, w, h);
    c.restore();
    c.lineWidth = 2; c.strokeStyle = 'rgba(255,255,255,0.55)'; rr(c, x, y, w, h, r); c.stroke();
  }
  function fluted(c, x, y, w, h, r, o, mask) {
    if (mask) { c.fillStyle = '#fff'; rr(c, x, y, w, h, r); c.fill(); return; }
    c.save(); c.shadowColor = 'rgba(0,0,0,0.38)'; c.shadowBlur = 36; c.shadowOffsetY = 18;
    var g = c.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, rgba(o.c1, 0.5)); g.addColorStop(1, rgba(o.c2, 0.5)); c.fillStyle = g; rr(c, x, y, w, h, r); c.fill(); c.restore();
    c.save(); rr(c, x, y, w, h, r); c.clip();
    for (var i = x; i < x + w; i += 18) { c.fillStyle = 'rgba(255,255,255,0.30)'; c.fillRect(i, y, 3, h); c.fillStyle = 'rgba(0,0,0,0.14)'; c.fillRect(i + 9, y, 3, h); }
    c.restore(); c.lineWidth = 2; c.strokeStyle = 'rgba(255,255,255,0.6)'; rr(c, x, y, w, h, r); c.stroke();
  }
  function avatar(c, cx, cy, r, ch, o) {
    var g = c.createLinearGradient(cx - r, cy - r, cx + r, cy + r); g.addColorStop(0, o.c1); g.addColorStop(1, o.c2);
    c.save(); c.shadowColor = rgba(o.c1, 0.7); c.shadowBlur = 24; c.fillStyle = g; c.beginPath(); c.arc(cx, cy, r, 0, 7); c.fill(); c.restore();
    c.fillStyle = '#04140d'; c.font = '700 ' + Math.round(r * 0.95) + 'px ' + FONT; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(ch, cx, cy + r * 0.04);
  }
  function setup(c, o, p) { c.globalAlpha = p.a; c.direction = 'rtl'; c.textBaseline = 'middle'; }
  var T = L.templates = {
    lower: { n: 'لاوەر سێرد (شووشە)', blur: true, draw: function (c, t, o, mask) {
      var W = o.W, H = o.H, k = H / 1080, p = pose(t, o), w = Math.min(W * 0.62, 820 * k + 100), h = 150 * k, x = W * 0.06, y = H - h - H * 0.09 + p.dy;
      if (o.vertical) { x = W * 0.05; w = W * 0.9; }
      c.save(); setup(c, o, p); glass(c, x, y, w, h, h / 2, o, mask);
      if (!mask) {
        avatar(c, x + w - h / 2, y + h / 2, h * 0.34, (o.text || 'ک').trim().charAt(0), o);
        c.textAlign = 'right'; c.fillStyle = '#fff'; c.font = '700 ' + Math.round(46 * k) + 'px ' + FONT; c.fillText(o.text, x + w - h * 0.95, y + h * 0.37);
        c.fillStyle = 'rgba(255,255,255,0.8)'; c.font = '500 ' + Math.round(27 * k) + 'px ' + FONT; c.fillText(o.sub, x + w - h * 0.95, y + h * 0.7);
      }
      c.restore();
    } },
    card: { n: 'کارتی وتە (شووشە)', blur: true, draw: function (c, t, o, mask) {
      var W = o.W, H = o.H, k = H / 1080, p = pose(t, o), w = Math.min(W * 0.62, 900 * k), h = 380 * k, x = (W - w) / 2, y = (H - h) / 2 + p.dy;
      c.save(); setup(c, o, p); glass(c, x, y, w, h, 40 * k, o, mask);
      if (!mask) {
        c.textAlign = 'center'; c.fillStyle = o.c1; c.font = '700 ' + Math.round(110 * k) + 'px ' + FONT; c.fillText('“', W / 2, y + h * 0.16);
        c.fillStyle = '#fff'; c.font = '600 ' + Math.round(46 * k) + 'px ' + FONT; var ls = L.wrap(c, o.text, w - 90 * k), i;
        for (i = 0; i < ls.length; i++) c.fillText(ls[i], W / 2, y + h * 0.42 + i * 66 * k - (ls.length - 1) * 22 * k);
        c.fillStyle = 'rgba(255,255,255,0.75)'; c.font = '500 ' + Math.round(28 * k) + 'px ' + FONT; c.fillText(o.sub, W / 2, y + h * 0.88);
      }
      c.restore();
    } },
    fluted: { n: 'بۆکسی ڕیزدار (کاپشن)', blur: true, draw: function (c, t, o, mask) {
      var W = o.W, H = o.H, k = H / 1080, p = pose(t, o), w = Math.min(W * 0.66, 1000 * k);
      c.save(); setup(c, o, p); c.font = '700 ' + Math.round(52 * k) + 'px ' + FONT; var ls = L.wrap(c, o.text, w - 100 * k), h = ls.length * 82 * k + 70 * k, x = (W - w) / 2, y = (H - h) / 2 + H * 0.1 + p.dy, i;
      fluted(c, x, y, w, h, 24 * k, o, mask);
      if (!mask) { c.textAlign = 'center'; c.fillStyle = '#fff'; c.shadowColor = 'rgba(0,0,0,0.5)'; c.shadowBlur = 12; for (i = 0; i < ls.length; i++) c.fillText(ls[i], W / 2, y + 35 * k + 41 * k + i * 82 * k); }
      c.restore();
    } },
    notif: { n: 'نوتیفیکەیشن (شووشە)', blur: true, draw: function (c, t, o, mask) {
      var W = o.W, H = o.H, k = H / 1080, p = pose(t, o), w = Math.min(W * 0.55, 780 * k + 80), h = 130 * k, x = (W - w) / 2, y = H * 0.08 - (1 - outC(t / 0.55)) * 90 * k;
      c.save(); setup(c, o, p); glass(c, x, y, w, h, h / 2, o, mask);
      if (!mask) {
        avatar(c, x + w - h / 2, y + h / 2, h * 0.32, '★', o);
        c.textAlign = 'right'; c.fillStyle = '#fff'; c.font = '700 ' + Math.round(40 * k) + 'px ' + FONT; c.fillText(o.text, x + w - h * 0.92, y + h * 0.37);
        c.fillStyle = 'rgba(255,255,255,0.8)'; c.font = '500 ' + Math.round(26 * k) + 'px ' + FONT; c.fillText(o.sub, x + w - h * 0.92, y + h * 0.7);
      }
      c.restore();
    } },
    follow: { n: 'کارتی فۆڵۆ (شووشە)', blur: true, draw: function (c, t, o, mask) {
      var W = o.W, H = o.H, k = H / 1080, p = pose(t, o), w = Math.min(W * 0.58, 860 * k + 60), h = 140 * k, x = (W - w) / 2, y = H * 0.78 + p.dy;
      c.save(); setup(c, o, p); glass(c, x, y, w, h, h / 2, o, mask);
      if (!mask) {
        avatar(c, x + w - h / 2, y + h / 2, h * 0.36, (o.text || 'ک').trim().charAt(0), o);
        c.textAlign = 'right'; c.fillStyle = '#fff'; c.font = '700 ' + Math.round(42 * k) + 'px ' + FONT; c.fillText(o.text, x + w - h * 0.95, y + h * 0.38);
        c.fillStyle = 'rgba(255,255,255,0.78)'; c.font = '500 ' + Math.round(26 * k) + 'px ' + FONT; c.fillText(o.sub, x + w - h * 0.95, y + h * 0.7);
        var bw = 190 * k, bh = 66 * k, bx = x + 38 * k, by = y + (h - bh) / 2, g = c.createLinearGradient(bx, 0, bx + bw, 0); g.addColorStop(0, o.c1); g.addColorStop(1, o.c2);
        c.fillStyle = g; rr(c, bx, by, bw, bh, bh / 2); c.fill(); c.fillStyle = '#04140d'; c.textAlign = 'center'; c.font = '700 ' + Math.round(30 * k) + 'px ' + FONT; c.fillText(o.btn || 'فۆڵۆ', bx + bw / 2, by + bh / 2 + 2);
      }
      c.restore();
    } },
    text: { n: 'تێکستی شووشەیی (دڵۆپی ئاو)', blur: false, draw: function (c, t, o, mask) {
      if (mask) return;
      var W = o.W, H = o.H, k = H / 1080, p = pose(t, o), size = Math.round(190 * k);
      c.save(); setup(c, o, p); c.translate(0, p.dy); c.textAlign = 'center'; c.font = '800 ' + size + 'px ' + FONT;
      var m = c.measureText(o.text).width; if (m > W * 0.9) { size = Math.floor(size * W * 0.9 / m); c.font = '800 ' + size + 'px ' + FONT; }
      var cx = W / 2, cy = H / 2;
      c.save(); c.shadowColor = 'rgba(0,0,0,0.4)'; c.shadowBlur = 24; c.shadowOffsetY = 14; c.fillStyle = rgba(o.c1, 0.3); c.fillText(o.text, cx, cy); c.restore();
      c.lineJoin = 'round'; c.lineWidth = 6; c.strokeStyle = rgba('#ffffff', 0.9); c.strokeText(o.text, cx, cy);
      c.save(); c.lineWidth = 2; c.strokeStyle = rgba(o.c1, 0.9); c.strokeText(o.text, cx, cy); c.restore();
      c.save(); c.fillStyle = (function () { var g = c.createLinearGradient(0, cy - size / 2, 0, cy + size / 2); g.addColorStop(0, 'rgba(255,255,255,0.55)'); g.addColorStop(0.5, 'rgba(255,255,255,0.05)'); g.addColorStop(1, rgba(o.c2, 0.35)); return g; })(); c.fillText(o.text, cx, cy); c.restore();
      c.restore();
    } },
    counter: { n: 'ژمێرەر (شووشە)', blur: true, draw: function (c, t, o, mask) {
      var W = o.W, H = o.H, k = H / 1080, p = pose(t, o), v = Math.round((o.to || 0) * outC(t / Math.max(0.6, o.dur * 0.65))), s = (o.prefix || '') + String(v).replace(/\B(?=(\d{3})+(?!\d))/g, ',') + (o.suffix || '');
      c.save(); setup(c, o, p); var big = Math.round(170 * k); c.font = '300 ' + big + 'px ' + FONT; var w = Math.max(c.measureText(s).width + 160 * k, 560 * k), h = 380 * k, x = (W - w) / 2, y = (H - h) / 2 + p.dy;
      glass(c, x, y, w, h, 44 * k, o, mask);
      if (!mask) { c.textAlign = 'center'; c.fillStyle = '#fff'; c.direction = 'ltr'; c.font = '300 ' + big + 'px ' + FONT; c.fillText(s, W / 2, y + h * 0.42); c.direction = 'rtl'; c.fillStyle = 'rgba(255,255,255,0.85)'; c.font = '600 ' + Math.round(40 * k) + 'px ' + FONT; c.fillText(o.text, W / 2, y + h * 0.82); }
      c.restore();
    } }
  };


  // ---------- قاڵبە ڕەقەکان (بێ شووشە) ----------
  function solid(c, x, y, w, h, r, col) { c.fillStyle = col; rr(c, x, y, w, h, r); c.fill(); }
  function parts(t) { return String(t || '').split('|').map(function (x) { return x.trim(); }); }
  T.lowerbar = { n: 'لاوەر سێرد: بلۆک', blur: false, hint: 'نووسینی سەرەکی = ناو، ژێرەوە = پلە', draw: function (c, t, o, mask) {
    if (mask) return; var W = o.W, H = o.H, k = H / 1080, p = pose(t, o), h = 92 * k, y = H - h - H * 0.1 + p.dy, x = W * 0.06; c.save(); setup(c, o, p); c.font = '700 ' + Math.round(44 * k) + 'px ' + FONT;
    var w1 = c.measureText(o.text).width + 70 * k; c.font = '500 ' + Math.round(30 * k) + 'px ' + FONT; var w2 = c.measureText(o.sub).width + 60 * k, wv = outC(t / 0.6);
    var g = c.createLinearGradient(x, 0, x + w1, 0); g.addColorStop(0, o.c1); g.addColorStop(1, o.c2); c.save(); c.shadowColor = 'rgba(0,0,0,0.4)'; c.shadowBlur = 20; c.shadowOffsetY = 8;
    c.beginPath(); c.rect(x + w2 * (1 - wv) * 0, y, (w1 + w2) * wv, h); c.clip(); c.fillStyle = 'rgba(8,18,14,0.94)'; c.fillRect(x, y, w1 + w2, h); c.fillStyle = g; c.fillRect(x + w2, y, w1, h); c.restore();
    c.textAlign = 'center'; c.fillStyle = '#04140d'; c.font = '700 ' + Math.round(44 * k) + 'px ' + FONT; c.fillText(o.text, x + w2 + w1 / 2, y + h / 2 + 2); c.fillStyle = '#b9f3d6'; c.font = '500 ' + Math.round(30 * k) + 'px ' + FONT; c.fillText(o.sub, x + w2 / 2, y + h / 2 + 2); c.restore(); } };
  T.lowerstripe = { n: 'لاوەر سێرد: هێڵ', blur: false, hint: 'نووسینی سەرەکی = ناو، ژێرەوە = پلە', draw: function (c, t, o, mask) {
    if (mask) return; var W = o.W, H = o.H, k = H / 1080, p = pose(t, o), x = W * 0.06, y = H - 190 * k - H * 0.06 + p.dy; c.save(); setup(c, o, p); c.font = '700 ' + Math.round(54 * k) + 'px ' + FONT;
    var w = Math.max(c.measureText(o.text).width, 360 * k) + 90 * k, h = 138 * k; c.shadowColor = 'rgba(0,0,0,0.4)'; c.shadowBlur = 20; solid(c, x, y, w, h, 10 * k, 'rgba(8,18,14,0.92)'); c.shadowBlur = 0; solid(c, x + w - 12 * k, y, 12 * k, h, 6 * k, o.c1);
    c.textAlign = 'right'; c.fillStyle = '#fff'; c.fillText(o.text, x + w - 40 * k, y + h * 0.38); c.fillStyle = o.c1; c.font = '500 ' + Math.round(32 * k) + 'px ' + FONT; c.fillText(o.sub, x + w - 40 * k, y + h * 0.75); c.restore(); } };
  T.ticker = { n: 'تیکەری هەواڵ', blur: false, hint: 'نووسینی سەرەکی = ڕستەی تیکەر، ژێرەوە = ناونیشانی لای ڕاست', draw: function (c, t, o, mask) {
    if (mask) return; var W = o.W, H = o.H, k = H / 1080, p = pose(t, o), h = 84 * k, y = H - h - H * 0.03 + p.dy; c.save(); setup(c, o, p); solid(c, 0, y, W, h, 0, 'rgba(8,18,14,0.95)');
    var lw = 230 * k; solid(c, W - lw, y, lw, h, 0, o.c1); c.fillStyle = '#04140d'; c.textAlign = 'center'; c.font = '700 ' + Math.round(36 * k) + 'px ' + FONT; c.fillText(o.sub || 'هەواڵ', W - lw / 2, y + h / 2 + 2);
    c.save(); c.beginPath(); c.rect(0, y, W - lw, h); c.clip(); c.font = '600 ' + Math.round(38 * k) + 'px ' + FONT; var tw = c.measureText(o.text).width + 200 * k, off = (t * 160 * k) % tw; c.fillStyle = '#fff'; c.textAlign = 'right';
    for (var i = -1; i < 3; i++) c.fillText(o.text, W - lw - 40 * k + off - i * tw + 0, y + h / 2 + 2); c.restore(); c.restore(); } };
  T.breaking = { n: 'هەواڵی بەپەلە', blur: false, hint: 'نووسینی سەرەکی = ناونیشان، ژێرەوە = وشەی سووری (بەپەلە)', draw: function (c, t, o, mask) {
    if (mask) return; var W = o.W, H = o.H, k = H / 1080, p = pose(t, o); c.save(); setup(c, o, p); c.font = '800 ' + Math.round(54 * k) + 'px ' + FONT; var ls = L.wrap(c, o.text, W * 0.8), h = ls.length * 78 * k + 44 * k, x = W * 0.07, w = W * 0.86, y = H - h - 70 * k - H * 0.07 + p.dy, i;
    c.shadowColor = 'rgba(0,0,0,0.45)'; c.shadowBlur = 24; solid(c, x, y, w, h, 12 * k, 'rgba(8,18,14,0.95)'); c.shadowBlur = 0;
    c.font = '800 ' + Math.round(38 * k) + 'px ' + FONT; var lw = c.measureText(o.sub || 'بەپەلە').width + 60 * k; solid(c, x + w - lw - 20 * k, y - 34 * k, lw, 68 * k, 10 * k, '#d92b3a'); c.fillStyle = '#fff'; c.textAlign = 'center'; c.fillText(o.sub || 'بەپەلە', x + w - lw / 2 - 20 * k, y + 2 * k);
    c.font = '800 ' + Math.round(54 * k) + 'px ' + FONT; c.textAlign = 'right'; for (i = 0; i < ls.length; i++) c.fillText(ls[i], x + w - 40 * k, y + 56 * k + i * 78 * k); c.restore(); } };
  T.score = { n: 'سکۆربۆرد', blur: false, hint: 'نووسینی سەرەکی = هەردوو تیم بە | (هەولێر|دهۆک)، ژێرەوە = ئەنجام بە | (٢|١)', draw: function (c, t, o, mask) {
    if (mask) return; var W = o.W, H = o.H, k = H / 1080, p = pose(t, o), tm = parts(o.text), sc = parts(o.sub), w = 760 * k, h = 120 * k, x = (W - w) / 2, y = H * 0.07 - (1 - outC(t / 0.55)) * 80 * k; c.save(); setup(c, o, p);
    c.shadowColor = 'rgba(0,0,0,0.45)'; c.shadowBlur = 24; solid(c, x, y, w, h, 16 * k, 'rgba(8,18,14,0.95)'); c.shadowBlur = 0; solid(c, x + w / 2 - 110 * k, y, 220 * k, h, 0, o.c1);
    c.textAlign = 'center'; c.fillStyle = '#04140d'; c.direction = 'ltr'; c.font = '800 ' + Math.round(70 * k) + 'px ' + FONT; c.fillText((sc[0] || '0') + ' : ' + (sc[1] || '0'), W / 2, y + h / 2 + 3);
    c.direction = 'rtl'; c.fillStyle = '#fff'; c.font = '700 ' + Math.round(38 * k) + 'px ' + FONT; c.fillText(tm[0] || '', x + w * 0.78, y + h / 2 + 2); c.fillText(tm[1] || '', x + w * 0.22, y + h / 2 + 2); c.restore(); } };
  T.progress = { n: 'پڕۆگرێس بار', blur: false, hint: 'نووسینی سەرەکی = ناونیشان، ژمارە = ڕێژە (٠–١٠٠)', draw: function (c, t, o, mask) {
    if (mask) return; var W = o.W, H = o.H, k = H / 1080, p = pose(t, o), v = Math.max(0, Math.min(100, o.to || 72)) * outC(t / Math.max(0.6, o.dur * 0.65)), w = Math.min(W * 0.6, 900 * k), x = (W - w) / 2, y = H * 0.5 + p.dy; c.save(); setup(c, o, p);
    c.textAlign = 'right'; c.fillStyle = '#fff'; c.font = '700 ' + Math.round(48 * k) + 'px ' + FONT; c.fillText(o.text, x + w, y - 40 * k); c.textAlign = 'left'; c.direction = 'ltr'; c.fillStyle = o.c1; c.fillText(Math.round(v) + '%', x, y - 40 * k);
    solid(c, x, y, w, 30 * k, 15 * k, 'rgba(255,255,255,0.15)'); var g = c.createLinearGradient(x, 0, x + w, 0); g.addColorStop(0, o.c2); g.addColorStop(1, o.c1); c.save(); c.shadowColor = rgba(o.c1, 0.6); c.shadowBlur = 20; solid(c, x, y, Math.max(30 * k, w * v / 100), 30 * k, 15 * k, g); c.restore(); c.restore(); } };
  T.versus = { n: 'ڤێرسەس', blur: false, hint: 'نووسینی سەرەکی = دوو ناو بە | (تیمی ١|تیمی ٢)', draw: function (c, t, o, mask) {
    if (mask) return; var W = o.W, H = o.H, k = H / 1080, p = pose(t, o), n = parts(o.text), r = 120 * k, cy = H / 2, d = 330 * k * outC(t / 0.7); c.save(); setup(c, o, p);
    [[W / 2 + d, n[0] || 'أ', o.c1], [W / 2 - d, n[1] || 'ب', o.c2]].forEach(function (a) { var g = c.createLinearGradient(a[0] - r, cy - r, a[0] + r, cy + r); g.addColorStop(0, a[2]); g.addColorStop(1, rgba(a[2], 0.6)); c.save(); c.shadowColor = rgba(a[2], 0.6); c.shadowBlur = 40; c.fillStyle = g; c.beginPath(); c.arc(a[0], cy, r, 0, 7); c.fill(); c.restore();
      c.fillStyle = '#04140d'; c.textAlign = 'center'; c.font = '800 ' + Math.round(110 * k) + 'px ' + FONT; c.fillText(a[1].charAt(0), a[0], cy + 4); c.fillStyle = '#fff'; c.font = '700 ' + Math.round(44 * k) + 'px ' + FONT; c.fillText(a[1], a[0], cy + r + 60 * k); });
    c.fillStyle = '#fff'; c.textAlign = 'center'; c.direction = 'ltr'; c.shadowColor = 'rgba(0,0,0,0.5)'; c.shadowBlur = 20; c.font = '900 ' + Math.round(96 * k) + 'px ' + FONT; c.save(); c.translate(W / 2, cy); var sp = 0.7 + 0.3 * outC((t - 0.3) / 0.4); c.scale(sp, sp); c.fillText('VS', 0, 0); c.restore(); c.restore(); } };
  T.timeline = { n: 'تایم‌لاین', blur: false, hint: 'نووسینی سەرەکی = خاڵەکان بە | (٢٠٢٤: دامەزراندن|٢٠٢٥: گەشە)', draw: function (c, t, o, mask) {
    if (mask) return; var W = o.W, H = o.H, k = H / 1080, p = pose(t, o), it = parts(o.text).slice(0, 6), x = W * 0.62, gap = 120 * k, y0 = H / 2 - (it.length - 1) * gap / 2, i, a; c.save(); setup(c, o, p);
    c.strokeStyle = rgba('#ffffff', 0.25); c.lineWidth = 6 * k; c.beginPath(); c.moveTo(x, y0 - 40 * k); c.lineTo(x, y0 + (it.length - 1) * gap + 40 * k); c.stroke();
    c.strokeStyle = o.c1; c.beginPath(); c.moveTo(x, y0 - 40 * k); c.lineTo(x, y0 - 40 * k + ((it.length - 1) * gap + 80 * k) * outC(t / (0.4 * it.length + 0.4))); c.stroke();
    for (i = 0; i < it.length; i++) { a = cl((t - 0.3 - i * 0.4) / 0.4); c.globalAlpha = p.a * a; c.fillStyle = o.c1; c.beginPath(); c.arc(x, y0 + i * gap, 16 * k, 0, 7); c.fill(); c.fillStyle = '#fff'; c.textAlign = 'right'; c.font = '600 ' + Math.round(44 * k) + 'px ' + FONT; c.fillText(it[i], x - 50 * k - (1 - outC(a)) * 40 * k, y0 + i * gap + 2); } c.restore(); } };
  T.endscreen = { n: 'ئێند سکرین', blur: false, hint: 'نووسینی سەرەکی = پەیام، ژێرەوە = دوگمە', draw: function (c, t, o, mask) {
    if (mask) return; var W = o.W, H = o.H, k = H / 1080, p = pose(t, o), s = outC((t - 0.25) / 0.5); c.save(); setup(c, o, p); c.textAlign = 'center'; c.fillStyle = '#fff'; c.shadowColor = 'rgba(0,0,0,0.5)'; c.shadowBlur = 24; c.font = '800 ' + Math.round(110 * k) + 'px ' + FONT; c.fillText(o.text, W / 2, H * 0.44 + p.dy);
    c.shadowBlur = 0; c.font = '700 ' + Math.round(44 * k) + 'px ' + FONT; var bw = c.measureText(o.sub).width + 110 * k, bh = 100 * k; c.save(); c.translate(W / 2, H * 0.62); c.scale(0.7 + 0.3 * s, 0.7 + 0.3 * s); c.globalAlpha = p.a * cl(s * 2);
    var g = c.createLinearGradient(-bw / 2, 0, bw / 2, 0); g.addColorStop(0, o.c1); g.addColorStop(1, o.c2); c.shadowColor = rgba(o.c1, 0.6); c.shadowBlur = 30; solid(c, -bw / 2, -bh / 2, bw, bh, bh / 2, g); c.shadowBlur = 0; c.fillStyle = '#04140d'; c.fillText(o.sub, 0, 3); c.restore(); c.restore(); } };
  T.subtitle = { n: 'ژێرنووسی بۆکس', blur: false, hint: 'نووسینی سەرەکی = ژێرنووس', draw: function (c, t, o, mask) {
    if (mask) return; var W = o.W, H = o.H, k = H / 1080, p = pose(t, o); c.save(); setup(c, o, p); c.font = '700 ' + Math.round(50 * k) + 'px ' + FONT; var ls = L.wrap(c, o.text, W * 0.78), h = ls.length * 74 * k + 30 * k, w = W * 0.84, x = (W - w) / 2, y = H - h - H * 0.07 + p.dy, i;
    solid(c, x, y, w, h, 14 * k, 'rgba(0,0,0,0.68)'); solid(c, x + 40 * k, y + h - 6 * k, w - 80 * k, 6 * k, 3 * k, o.c1); c.textAlign = 'center'; c.fillStyle = '#fff'; for (i = 0; i < ls.length; i++) c.fillText(ls[i], W / 2, y + 15 * k + 37 * k + i * 74 * k); c.restore(); } };

  // ---------- ستایلی تێکستی تایبەت ----------
  L.TEXTFX = [['neon', 'نیۆن'], ['gold', 'زێڕ'], ['chrome', 'کرۆم'], ['outline', 'هێڵی'], ['glitch', 'گلیچ'], ['longshadow', 'سێبەری درێژ'], ['sticker', 'ستیکەر'], ['extrude', '٣D'], ['fire', 'ئاگر'], ['ice', 'سەهۆڵ'], ['gradient', 'گرادیەنت']];
  function lg(c, y0, y1, stops) { var g = c.createLinearGradient(0, y0, 0, y1); stops.forEach(function (s) { g.addColorStop(s[0], s[1]); }); return g; }
  T.textfx = { n: 'ستایلی تێکستی تایبەت', blur: false, draw: function (c, t, o, mask) {
    if (mask) return;
    var W = o.W, H = o.H, k = H / 1080, st = o.style || 'neon', p = outC(t / 0.5), e = env(t, o.dur), size = Math.round(200 * k), tx = o.text || 'KZ';
    c.save(); c.globalAlpha = e; c.direction = 'rtl'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.lineJoin = 'round';
    c.font = '800 ' + size + 'px ' + FONT; var m = c.measureText(tx).width; if (m > W * 0.9) { size = Math.floor(size * W * 0.9 / m); c.font = '800 ' + size + 'px ' + FONT; }
    var cx = W / 2, cy = H / 2, y0 = cy - size * 0.6, y1 = cy + size * 0.6, sc = 0.8 + 0.2 * p + (p > 0.98 ? 0 : 0);
    c.translate(cx, cy); c.scale(sc, sc); c.translate(-cx, -cy);
    var i, sweep = cl((t - 0.5) / 1.1);
    function shine() { if (sweep <= 0 || sweep >= 1) return; c.save(); c.globalCompositeOperation = 'source-atop'; var x = cx - m / 2 - size + (m + size * 2) * sweep, g = c.createLinearGradient(x - size * 0.3, 0, x + size * 0.3, 0); g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(0.5, 'rgba(255,255,255,0.85)'); g.addColorStop(1, 'rgba(255,255,255,0)'); c.fillStyle = g; c.fillRect(cx - m, y0 - size, m * 2, size * 3); c.restore(); }
    if (st === 'neon') {
      c.fillStyle = o.c1; c.shadowColor = o.c1; for (i = 0; i < 4; i++) { c.shadowBlur = 18 + i * 22; c.globalAlpha = e * 0.55; c.strokeStyle = o.c1; c.lineWidth = 5; c.strokeText(tx, cx, cy); }
      c.globalAlpha = e; c.shadowBlur = 12; c.lineWidth = 6; c.strokeStyle = o.c1; c.strokeText(tx, cx, cy); c.shadowBlur = 0; c.lineWidth = 3; c.strokeStyle = '#fff'; c.strokeText(tx, cx, cy);
      c.fillStyle = 'rgba(255,255,255,0.12)'; c.fillText(tx, cx, cy);
    } else if (st === 'gold') {
      c.save(); c.shadowColor = 'rgba(0,0,0,0.55)'; c.shadowBlur = 20; c.shadowOffsetY = 10; c.lineWidth = 12; c.strokeStyle = '#4a2f08'; c.strokeText(tx, cx, cy); c.restore();
      c.fillStyle = lg(c, y0, y1, [[0, '#fff6c2'], [0.45, '#f4c542'], [0.55, '#9a6212'], [0.75, '#f7d36b'], [1, '#a8701a']]); c.fillText(tx, cx, cy); c.lineWidth = 2; c.strokeStyle = 'rgba(255,255,255,0.7)'; c.strokeText(tx, cx, cy); shine();
    } else if (st === 'chrome') {
      c.save(); c.shadowColor = 'rgba(0,0,0,0.5)'; c.shadowBlur = 20; c.shadowOffsetY = 10; c.lineWidth = 10; c.strokeStyle = '#1a2430'; c.strokeText(tx, cx, cy); c.restore();
      c.fillStyle = lg(c, y0, y1, [[0, '#ffffff'], [0.42, '#9fc3e8'], [0.5, '#1b2a3a'], [0.58, '#6f96bd'], [1, '#e9f4ff']]); c.fillText(tx, cx, cy); c.lineWidth = 2; c.strokeStyle = '#fff'; c.strokeText(tx, cx, cy); shine();
    } else if (st === 'outline') {
      c.lineWidth = 6; c.strokeStyle = o.c1; c.shadowColor = rgba(o.c1, 0.6); c.shadowBlur = 16; c.strokeText(tx, cx, cy); c.shadowBlur = 0; c.fillStyle = rgba(o.c1, 0.1); c.fillText(tx, cx, cy);
    } else if (st === 'glitch') {
      var j = (Math.floor(t * 18) % 5 === 0) ? 1 : 0, dx = (j ? 14 : 5) * k * (Math.sin(t * 90) > 0 ? 1 : -1);
      c.globalCompositeOperation = 'lighter'; c.fillStyle = '#ff2a55'; c.fillText(tx, cx - dx, cy + (j ? 4 : 0)); c.fillStyle = '#19e6ff'; c.fillText(tx, cx + dx, cy - (j ? 4 : 0)); c.fillStyle = '#ffffff'; c.globalCompositeOperation = 'source-over'; c.fillText(tx, cx, cy);
      if (j) { c.globalCompositeOperation = 'destination-out'; c.fillRect(0, cy - size * 0.1, W, size * 0.07); c.globalCompositeOperation = 'source-over'; }
    } else if (st === 'longshadow') {
      var n = Math.round(90 * k); c.fillStyle = o.c2; for (i = n; i >= 1; i--) c.fillText(tx, cx + i * 0.9 * k, cy + i * 0.9 * k); c.fillStyle = '#fff'; c.fillText(tx, cx, cy);
    } else if (st === 'sticker') {
      c.save(); c.shadowColor = 'rgba(0,0,0,0.45)'; c.shadowBlur = 24; c.shadowOffsetY = 12; c.lineWidth = 34 * k; c.strokeStyle = '#fff'; c.strokeText(tx, cx, cy); c.restore();
      c.lineWidth = 34 * k; c.strokeStyle = '#fff'; c.strokeText(tx, cx, cy); c.fillStyle = o.c1; c.fillText(tx, cx, cy); c.lineWidth = 3; c.strokeStyle = 'rgba(0,0,0,0.25)'; c.strokeText(tx, cx, cy);
    } else if (st === 'extrude') {
      var d = Math.round(36 * k); for (i = d; i >= 1; i--) { c.fillStyle = i % 2 ? o.c2 : rgba(o.c2, 0.92); c.fillText(tx, cx + i * 0.8, cy + i * 0.9); }
      c.fillStyle = o.c1; c.fillText(tx, cx, cy); c.lineWidth = 3; c.strokeStyle = 'rgba(255,255,255,0.65)'; c.strokeText(tx, cx, cy);
    } else if (st === 'fire') {
      c.save(); c.shadowColor = '#ff7a18'; c.shadowBlur = 50; c.fillStyle = '#ff7a18'; c.globalAlpha = e * 0.6; c.fillText(tx, cx, cy - 6); c.restore();
      c.fillStyle = lg(c, y0, y1, [[0, '#fff7a8'], [0.35, '#ffd23a'], [0.7, '#ff6a00'], [1, '#c4180c']]); c.fillText(tx, cx, cy); c.lineWidth = 2; c.strokeStyle = 'rgba(120,20,0,0.6)'; c.strokeText(tx, cx, cy);
    } else if (st === 'ice') {
      c.save(); c.shadowColor = '#7fd8ff'; c.shadowBlur = 40; c.fillStyle = '#7fd8ff'; c.globalAlpha = e * 0.5; c.fillText(tx, cx, cy); c.restore();
      c.fillStyle = lg(c, y0, y1, [[0, '#ffffff'], [0.5, '#bfeaff'], [1, '#4aa9e8']]); c.fillText(tx, cx, cy); c.lineWidth = 3; c.strokeStyle = 'rgba(255,255,255,0.9)'; c.strokeText(tx, cx, cy); shine();
    } else {
      var g = c.createLinearGradient(cx - m / 2, 0, cx + m / 2, 0); g.addColorStop(0, o.c1); g.addColorStop(1, o.c2); c.save(); c.shadowColor = 'rgba(0,0,0,0.4)'; c.shadowBlur = 22; c.shadowOffsetY = 12; c.fillStyle = g; c.fillText(tx, cx, cy); c.restore();
    }
    c.restore();
  } };
  L.drawFrame = function (c, t, o, mask) { c.clearRect(0, 0, o.W, o.H); if (mask) { c.fillStyle = '#000'; c.fillRect(0, 0, o.W, o.H); } T[o.tpl].draw(c, t, o, mask); };
  // ffmpeg: بلەری پاشخان + شووشە
  L.blurArgs = function (o, src, ss, glassPat, maskPat, out) {
    var f = o.fps || 30, W = o.W, H = o.H, sig = o.blur || 24;
    var fc = '[0:v]scale=' + W + ':' + H + ':force_original_aspect_ratio=increase,crop=' + W + ':' + H + ',fps=' + f + ',format=yuv420p,split[a][b];' +
      '[b]gblur=sigma=' + sig + ',format=yuv420p[bl];[2:v]format=gray[m];[a][bl][m]maskedmerge[x];[x][1:v]overlay=format=auto:shortest=1,format=yuv420p[o]';
    return ['-y', '-hide_banner', '-ss', String(Math.max(0, ss)), '-t', String(o.dur), '-i', src, '-framerate', String(f), '-i', glassPat, '-framerate', String(f), '-i', maskPat, '-filter_complex', fc, '-map', '[o]', '-t', String(o.dur), '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '17', '-an', out];
  };
  L.alphaArgs = function (o, glassPat, out) {
    return ['-y', '-hide_banner', '-framerate', String(o.fps || 30), '-i', glassPat, '-c:v', 'prores_ks', '-profile:v', '4', '-pix_fmt', 'yuva444p10le', out];
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = L; else root.KZ_LIB4 = L;
})(typeof window !== 'undefined' ? window : this);
