/* KZ Tools — ترانزیشنی تایبەت */
(function () {
  'use strict';
  var KZ = window.KZ, L1 = window.KZ_LIB, L3 = window.KZ_LIB3, fs = require('fs'), path = require('path'), $ = function (s) { return document.querySelector(s); };
  var busy = false;
  async function guard(fn) {
    if (!KZ.license.canUse()) { KZ.toast('کۆدی مۆڵەت پێویستە', 'bad'); return; }
    if (busy) { KZ.toast('کارێکی تر ماوە', 'bad'); return; }
    busy = true;
    try { await fn(); } catch (e) { KZ.toast('هەڵە: ' + (e && e.message || e), 'bad'); KZ.log('هەڵە: ' + (e && e.message || e)); }
    busy = false; KZ.progress(-1);
  }
  function ff() { var f = KZ.ffmpeg(); if (!f) KZ.toast('ffmpeg نەدۆزرایەوە. لە «ڕێکخستن» دایبەزێنە', 'bad'); return f; }
  function trk(id, d) { return Math.max(0, (parseInt($(id).value, 10) || d) - 1); }

  // ---- ترانزیشنی تایبەت ----
  (function () {
    var kind = $('#xf-kind');
    L3.XFADES.forEach(function (x) { var o = document.createElement('option'); o.value = x[0]; o.textContent = x[1]; kind.appendChild(o); });
    async function xf() {
      if (!ff()) return;
      var s = await KZ.jsx('getSelection');
      if (!s.ok) { KZ.toast(s.error, 'bad'); return; }
      var cs = (s.clips || []).filter(function (x) { return x.path && x.kind === 'video'; }).sort(function (a, b) { return a.start - b.start; });
      if (cs.length < 2) { KZ.toast('دوو کلیپی ڤیدیۆی لکاو هەڵبژێرە', 'bad'); return; }
      var A = cs[0], B = cs[1], d = Math.max(0.3, Math.min(3, parseFloat($('#xf-dur').value) || 1)), f = $('#xf-fmt').value;
      var W = f === 'v' ? 1080 : f === 's' ? 1080 : 1920, H = f === 'v' ? 1920 : f === 's' ? 1080 : 1080;
      var aStart = Math.max(0, A.outPoint - d / 2), bs = B.inPoint - d / 2, pre = 0;
      if (bs < 0) { pre = -bs; bs = 0; }
      var out = path.join(KZ.workDir(), 'kz_xf_' + kind.value + '_' + Date.now() + '.mp4');
      KZ.progress(30, 'ڕەندەری ترانزیشن...');
      var r = await KZ.exec(ff(), L3.xfadeArgs({ name: kind.value, W: W, H: H, fps: 30, dur: d, a: A.path, aStart: aStart, b: B.path, bStart: bs, bPre: pre, out: out }));
      if (r.code !== 0) throw new Error('ffmpeg: ' + (r.err || '').slice(-200));
      var p = await KZ.jsx('placeVideo', { path: out, at: B.start - d / 2, track: trk('#xf-vt', 4) });
      if (!p.ok) { KZ.toast('دروست بوو بەڵام دانان نەکرا: ' + p.error, 'bad'); KZ.log(out); return; }
      KZ.toast('ترانزیشن دانرا');
    }
    $('#xf-go').onclick = function () { guard(xf); };
  })();

})();
