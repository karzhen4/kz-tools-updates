/* KZ Tools — ترانزیشنی تایبەت (xfade) */
(function (root) {
  'use strict';
  var L = {};
  // ترانزیشنی تایبەت بە ffmpeg xfade
  L.XFADES = [
    ['circleopen', 'بازنە: کردنەوە'], ['circleclose', 'بازنە: داخستن'], ['radial', 'تیشکی (ڕادیاڵ)'], ['pixelize', 'پیکسێل'], ['dissolve', 'تواندنەوەی خاڵدار'],
    ['hblur', 'بلەری ئاسۆیی'], ['distance', 'دووری'], ['fadegrays', 'ڕەش و سپی'], ['fadewhite', 'فلاشی سپی'], ['fadeblack', 'تاریکبوون'],
    ['squeezeh', 'پەستان: ئاسۆیی'], ['squeezev', 'پەستان: ستوونی'], ['hlslice', 'پارچە: ئاسۆیی'], ['vuslice', 'پارچە: ستوونی'], ['hlwind', 'با: چەپ'], ['vdwind', 'با: خوارەوە'],
    ['diagtl', 'لاری: سەرەوە-چەپ'], ['diagbr', 'لاری: خوارەوە-ڕاست'], ['smoothleft', 'نەرم: چەپ'], ['smoothup', 'نەرم: سەرەوە'], ['slideleft', 'خلیسکان: چەپ'], ['slideup', 'خلیسکان: سەرەوە'],
    ['wipetl', 'سڕین: سووچ'], ['horzopen', 'کردنەوەی ئاسۆیی'], ['vertclose', 'داخستنی ستوونی'], ['coverleft', 'داپۆشین: چەپ'], ['revealright', 'ئاشکرابوون: ڕاست']
  ];
  L.xfadeArgs = function (o) {
    var W = o.W, H = o.H, f = o.fps || 30, d = o.dur, pre = Math.max(0, o.bPre || 0);
    var norm = 'scale=' + W + ':' + H + ':force_original_aspect_ratio=increase,crop=' + W + ':' + H + ',fps=' + f + ',setsar=1,format=yuv420p';
    var fc = '[0:v]' + norm + ',tpad=stop_mode=clone:stop_duration=' + d + ',trim=duration=' + d + ',setpts=PTS-STARTPTS[a];' +
      '[1:v]' + norm + (pre > 0 ? ',tpad=start_mode=clone:start_duration=' + pre : '') + ',tpad=stop_mode=clone:stop_duration=' + d + ',trim=duration=' + d + ',setpts=PTS-STARTPTS[b];' +
      '[a][b]xfade=transition=' + o.name + ':duration=' + d + ':offset=0,format=yuv420p[o]';
    return ['-y', '-hide_banner', '-ss', String(Math.max(0, o.aStart)), '-t', String(d), '-i', o.a, '-ss', String(Math.max(0, o.bStart)), '-t', String(d), '-i', o.b,
      '-filter_complex', fc, '-map', '[o]', '-t', String(d), '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '17', '-an', o.out];
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = L; else root.KZ_LIB3 = L;
})(typeof window !== 'undefined' ? window : this);
