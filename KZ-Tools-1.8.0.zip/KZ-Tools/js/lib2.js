/* KZ Tools — فەنکشنە پاکەکانی بەشی دووەم (ffmpeg، LUT، ساوند، ئەنیمەیشن). بێ پشت بەستن بە Premiere. */
(function () {
  'use strict';
  var L2 = {};
  function clamp(x) { return x < 0 ? 0 : x > 1 ? 1 : x; }

  // ---------- جوڵە: ئیزینگ و ژمارە ----------
  L2.ease = {
    linear: function (t) { return t; },
    outCubic: function (t) { return 1 - Math.pow(1 - t, 3); },
    inOut: function (t) { return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; },
    outBack: function (t) { var c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); }
  };
  var AR = '٠١٢٣٤٥٦٧٨٩';
  L2.formatNumber = function (v, o) {
    o = o || {};
    var d = o.decimals || 0, neg = v < 0, s = Math.abs(v).toFixed(d), parts = s.split('.'), ip = parts[0], i, out = '';
    if (o.sep !== false) { for (i = 0; i < ip.length; i++) { if (i > 0 && (ip.length - i) % 3 === 0) out += (o.digits === 'arabic' ? '٬' : ','); out += ip.charAt(i); } } else out = ip;
    if (parts[1]) out += (o.digits === 'arabic' ? '٫' : '.') + parts[1];
    if (o.digits === 'arabic') out = out.replace(/[0-9]/g, function (c) { return AR.charAt(+c); });
    return (neg ? '-' : '') + out;
  };

  // ---------- خێرایی ----------
  L2.atempoChain = function (s) {
    var out = [];
    while (s < 0.5) { out.push('atempo=0.5'); s /= 0.5; }
    while (s > 2) { out.push('atempo=2.0'); s /= 2; }
    out.push('atempo=' + (Math.round(s * 10000) / 10000));
    return out.join(',');
  };
  L2.speedOutDuration = function (dur, stages) {
    var sum = 0, i, tot = 0; for (i = 0; i < stages.length; i++) sum += stages[i].p;
    for (i = 0; i < stages.length; i++) tot += (dur * stages[i].p / sum) / stages[i].speed;
    return tot;
  };
  L2.speedArgs = function (o) {
    var st = o.stages, sum = 0, i, acc = 0, v = [], a = [], cat = '';
    for (i = 0; i < st.length; i++) sum += st[i].p;
    for (i = 0; i < st.length; i++) {
      var t0 = acc, t1 = acc + o.dur * st[i].p / sum; acc = t1;
      v.push('[0:v]trim=start=' + t0.toFixed(4) + ':end=' + t1.toFixed(4) + ',setpts=(PTS-STARTPTS)/' + st[i].speed + '[v' + i + ']');
      if (o.hasAudio) a.push('[0:a]atrim=start=' + t0.toFixed(4) + ':end=' + t1.toFixed(4) + ',asetpts=PTS-STARTPTS,' + L2.atempoChain(st[i].speed) + '[a' + i + ']');
      cat += '[v' + i + ']' + (o.hasAudio ? '[a' + i + ']' : '');
    }
    cat += 'concat=n=' + st.length + ':v=1:a=' + (o.hasAudio ? 1 : 0) + '[v]' + (o.hasAudio ? '[a]' : '');
    var fg = v.concat(a, [cat]).join(';');
    var args = ['-y', '-hide_banner', '-ss', String(o.inSec), '-t', String(o.dur), '-i', o.src, '-filter_complex', fg, '-map', '[v]'];
    if (o.hasAudio) args.push('-map', '[a]');
    args.push('-c:v', 'libx264', '-preset', 'medium', '-crf', '18', '-pix_fmt', 'yuv420p');
    if (o.hasAudio) args.push('-c:a', 'aac', '-b:a', '192k');
    args.push('-movflags', '+faststart', o.out);
    return args;
  };

  // ---------- ساوند ئێفێکت (دروستکراو بە ffmpeg) ----------
  var ST = 'aformat=channel_layouts=stereo';
  L2.SFX = {
    whoosh: { label: 'ویش', graph: 'anoisesrc=d=1.1:c=pink:r=48000:a=0.9,lowpass=f=5000,highpass=f=250,afade=t=in:st=0:d=0.5,afade=t=out:st=0.5:d=0.6,' + ST + '[a]' },
    swipe: { label: 'سوایپ', graph: 'anoisesrc=d=0.45:c=pink:r=48000:a=0.9,lowpass=f=7000,highpass=f=400,afade=t=in:st=0:d=0.2,afade=t=out:st=0.2:d=0.25,' + ST + '[a]' },
    pop: { label: 'پۆپ', graph: "aevalsrc='sin(2*PI*(900*t-2500*t*t))*exp(-t*35)*0.9':d=0.2:s=48000," + ST + '[a]' },
    click: { label: 'کلیک', graph: 'anoisesrc=d=0.06:c=white:r=48000:a=0.9,highpass=f=1800,afade=t=out:st=0.005:d=0.05,' + ST + '[a]' },
    riser: { label: 'ڕایزەر', graph: "aevalsrc='0.55*sin(2*PI*(180*t+160*t*t))*(t/2.2)':d=2.2:s=48000[s];anoisesrc=d=2.2:c=pink:r=48000:a=0.5,highpass=f=1200,afade=t=in:st=0:d=2.2[n];[s][n]amix=inputs=2:duration=first,volume=1.8,afade=t=out:st=2.1:d=0.1," + ST + '[a]' },
    boom: { label: 'بووم', graph: "aevalsrc='0.95*sin(2*PI*(75*t-30*t*t))*exp(-t*3.2)':d=1.6:s=48000[s];anoisesrc=d=1.6:c=brown:r=48000:a=0.6,lowpass=f=300,afade=t=out:st=0:d=0.5[n];[s][n]amix=inputs=2:duration=first,volume=1.8," + ST + '[a]' },
    ding: { label: 'دینگ', graph: "aevalsrc='(sin(2*PI*1320*t)+0.5*sin(2*PI*1980*t)+0.25*sin(2*PI*2640*t))*exp(-t*5)*0.3':d=1.4:s=48000," + ST + '[a]' }
  };
  L2.sfxArgs = function (name, out) {
    return ['-y', '-hide_banner', '-filter_complex', L2.SFX[name].graph, '-map', '[a]', '-ar', '48000', '-c:a', 'pcm_s16le', out];
  };

  // ---------- دەنگی زیرەک (ducking) ----------
  L2.DUCK = { soft: { ratio: 4, release: 350 }, mid: { ratio: 8, release: 450 }, hard: { ratio: 16, release: 600 } };
  // music, voice: {path,inSec,dur,start(timeline)}
  L2.duckArgs = function (music, voice, level, out) {
    var lv = L2.DUCK[level] || L2.DUCK.mid, off = voice.start - music.start, vin = voice.inSec, vdur = voice.dur, delay = 0;
    if (off >= 0) delay = off; else { vin = voice.inSec - off; vdur = voice.dur + off; }
    var vf = 'aformat=channel_layouts=stereo,aresample=48000' + (delay > 0 ? ',adelay=' + Math.round(delay * 1000) + ':all=1' : '') + ',apad';
    var fg = '[0:a]aformat=channel_layouts=stereo,aresample=48000[m];[1:a]' + vf + '[v];[m][v]sidechaincompress=threshold=0.03:ratio=' + lv.ratio + ':attack=15:release=' + lv.release + ':makeup=1[o]';
    return ['-y', '-hide_banner', '-ss', String(music.inSec), '-t', String(music.dur), '-i', music.path, '-ss', String(Math.max(0, vin)), '-t', String(Math.max(0.01, vdur)), '-i', voice.path,
      '-filter_complex', fg, '-map', '[o]', '-t', String(music.dur), '-ar', '48000', '-c:a', 'pcm_s16le', out];
  };

  // ---------- شەپۆلی دەنگ (ProRes 4444 + ئەلفا) ----------
  L2.vizArgs = function (o) {
    var W = o.W, H = o.H, bh = o.bandH, y = Math.max(0, Math.min(H - bh, o.y)), hex = '0x' + String(o.color).replace('#', '');
    var src = o.mode === 'bars'
      ? '[0:a]showfreqs=s=' + W + 'x' + bh + ':mode=bar:fscale=log:ascale=sqrt:win_size=1024:colors=white,format=gray[m0]'
      : '[0:a]showwaves=s=' + W + 'x' + bh + ':mode=' + o.mode + ':rate=30:colors=white,format=gray[m0]';
    var fg = src + ';[m0]pad=' + W + ':' + H + ':0:' + y + ':black[m];color=c=' + hex + ':s=' + W + 'x' + H + ':r=30,format=rgba[c];[c][m]alphamerge,format=yuva444p10le[v]';
    return ['-y', '-hide_banner', '-ss', String(o.inSec), '-t', String(o.dur), '-i', o.src, '-filter_complex', fg, '-map', '[v]', '-t', String(o.dur), '-c:v', 'prores_ks', '-profile:v', '4', '-pix_fmt', 'yuva444p10le', o.out];
  };

  // ---------- LUT ----------
  L2.LOOKS = {
    cinematic: { label: 'سینەمایی', sat: 1.05, contrast: 1.12, gamma: 1, gain: [1, 1, 1], lift: [0, 0, 0], sh: [-0.02, 0.015, 0.045], hi: [0.045, 0.015, -0.03], fade: 0 },
    warm: { label: 'گەرم', sat: 1.08, contrast: 1.05, gamma: 1, gain: [1.05, 1.0, 0.92], lift: [0, 0, 0], sh: [0, 0, 0], hi: [0.02, 0.008, -0.02], fade: 0 },
    cool: { label: 'ساردی', sat: 1.0, contrast: 1.05, gamma: 1, gain: [0.94, 1.0, 1.07], lift: [0, 0, 0], sh: [0, 0.005, 0.02], hi: [0, 0, 0.015], fade: 0 },
    vintage: { label: 'کۆن', sat: 0.8, contrast: 0.95, gamma: 1, gain: [1, 1, 1], lift: [0, 0, 0], sh: [0, 0.015, 0], hi: [0.03, 0.02, -0.02], fade: 0.06 },
    bw: { label: 'ڕەش و سپی', sat: 0, contrast: 1.2, gamma: 1, gain: [1, 1, 1], lift: [0, 0, 0], sh: [0, 0, 0], hi: [0, 0, 0], fade: 0, bw: true },
    vivid: { label: 'زیندوو', sat: 1.35, contrast: 1.1, gamma: 1, gain: [1, 1, 1], lift: [0, 0, 0], sh: [0, 0, 0], hi: [0, 0, 0], fade: 0 },
    news: { label: 'هەواڵ (پاک)', sat: 1.1, contrast: 1.08, gamma: 1.05, gain: [1, 1, 1.02], lift: [0, 0, 0], sh: [0, 0, 0], hi: [0, 0, 0], fade: 0 },
    jade: { label: 'سەوزی KZ', sat: 1.05, contrast: 1.08, gamma: 1, gain: [1, 1, 1], lift: [0, 0, 0], sh: [-0.02, 0.03, 0], hi: [0, 0.02, 0.02], fade: 0 },
    tealorange: { label: 'سینەما: تیل و نارەنجی', sat: 1.12, contrast: 1.15, gamma: 1, gain: [1.03, 1, 0.97], lift: [0, 0, 0], sh: [-0.06, 0.03, 0.07], hi: [0.08, 0.03, -0.07], fade: 0 },
    blockbuster: { label: 'سینەما: بلۆکبەستەر', sat: 1.0, contrast: 1.24, gamma: 1, gain: [1, 1, 1.02], lift: [0, 0, 0], sh: [-0.05, 0, 0.06], hi: [0.03, 0.01, -0.02], fade: 0.02 },
    noir: { label: 'سینەما: نوار', sat: 0, contrast: 1.5, gamma: 0.95, gain: [1, 1, 1], lift: [0, 0, 0], sh: [0, 0, 0], hi: [0, 0, 0], fade: 0, bw: true },
    bleach: { label: 'سینەما: بلیچ باپەس', sat: 0.45, contrast: 1.35, gamma: 1, gain: [1, 1, 1], lift: [0, 0, 0], sh: [0, 0, 0.01], hi: [0.01, 0.01, 0], fade: 0 },
    goldenhour: { label: 'کاتی زێڕین', sat: 1.15, contrast: 1.08, gamma: 1, gain: [1.08, 1, 0.86], lift: [0, 0, 0], sh: [0.02, 0, -0.02], hi: [0.06, 0.03, -0.05], fade: 0 },
    thriller: { label: 'سینەما: تریلەر', sat: 0.8, contrast: 1.2, gamma: 0.95, gain: [0.93, 1, 1.05], lift: [0, 0, 0], sh: [-0.02, 0.02, 0.05], hi: [-0.01, 0.01, 0.03], fade: 0 },
    kodak: { label: 'فیلمی کۆداک', sat: 1.05, contrast: 1.0, gamma: 1, gain: [1.04, 1, 0.94], lift: [0, 0, 0], sh: [0.02, 0.01, 0], hi: [0.04, 0.02, -0.02], fade: 0.05 },
    cyberpunk: { label: 'سایبەرپەنک', sat: 1.3, contrast: 1.18, gamma: 1, gain: [1, 1, 1], lift: [0, 0, 0], sh: [-0.03, 0.04, 0.09], hi: [0.09, -0.03, 0.05], fade: 0 },
    matte: { label: 'ماتی فیلم', sat: 0.9, contrast: 0.88, gamma: 1, gain: [1, 1, 1], lift: [0, 0, 0], sh: [0, 0.01, 0.02], hi: [0, 0, 0], fade: 0.1 },
    sepia: { label: 'سێپیا', sat: 0.35, contrast: 1.05, gamma: 1, gain: [1.1, 1, 0.8], lift: [0, 0, 0], sh: [0.04, 0.02, -0.02], hi: [0.06, 0.04, -0.04], fade: 0.03 },
    daynight: { label: 'شەو بە ڕۆژ', sat: 0.7, contrast: 1.1, gamma: 0.85, gain: [0.8, 0.9, 1.15], lift: [0, 0, 0], sh: [-0.02, 0, 0.06], hi: [0, 0.01, 0.04], fade: 0 },
    horror: { label: 'سینەما: ترس', sat: 0.6, contrast: 1.25, gamma: 1, gain: [0.9, 1.05, 0.9], lift: [0, 0, 0], sh: [-0.03, 0.05, -0.02], hi: [0, 0.02, 0], fade: 0 },
    desert: { label: 'بیابان', sat: 0.85, contrast: 1.15, gamma: 1, gain: [1.1, 0.98, 0.82], lift: [0, 0, 0], sh: [0.02, 0, -0.03], hi: [0.06, 0.03, -0.04], fade: 0 },
    pastel: { label: 'پاستێل', sat: 0.9, contrast: 0.85, gamma: 1.1, gain: [1.03, 1, 1.04], lift: [0, 0, 0], sh: [0, 0, 0], hi: [0, 0, 0], fade: 0.08 },
    hdr: { label: 'HDR تیژ', sat: 1.3, contrast: 1.3, gamma: 1.05, gain: [1, 1, 1], lift: [0, 0, 0], sh: [0, 0, 0], hi: [0, 0, 0], fade: 0 },
    moonlight: { label: 'مانگەشەو (زیوی)', sat: 0.5, contrast: 1.1, gamma: 1, gain: [0.95, 1, 1.08], lift: [0, 0, 0], sh: [0, 0.01, 0.04], hi: [0, 0.01, 0.03], fade: 0.03 }
  };
  L2.grade = function (look, rgb, k) {
    var P = L2.LOOKS[look], r = rgb[0], g = rgb[1], b = rgb[2], R, G, B, lum, sh, hw, i, x;
    var c = [r, g, b];
    for (i = 0; i < 3; i++) {
      x = c[i] * P.gain[i] + P.lift[i];
      x = Math.pow(clamp(x), 1 / P.gamma);
      x = clamp(0.5 + (x - 0.5) * P.contrast);
      c[i] = x;
    }
    lum = 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
    sh = (1 - lum) * (1 - lum); hw = lum * lum;
    for (i = 0; i < 3; i++) c[i] = clamp(c[i] + P.sh[i] * sh + P.hi[i] * hw);
    lum = 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
    for (i = 0; i < 3; i++) c[i] = clamp(lum + (c[i] - lum) * P.sat);
    if (P.bw) { lum = 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; c = [lum, lum, lum]; }
    if (P.fade) for (i = 0; i < 3; i++) c[i] = P.fade + c[i] * (1 - P.fade);
    R = rgb[0] + (c[0] - rgb[0]) * k; G = rgb[1] + (c[1] - rgb[1]) * k; B = rgb[2] + (c[2] - rgb[2]) * k;
    return [clamp(R), clamp(G), clamp(B)];
  };
  L2.cube = function (look, k, N) {
    N = N || 33; var out = ['TITLE "KZ ' + look + '"', 'LUT_3D_SIZE ' + N, 'DOMAIN_MIN 0 0 0', 'DOMAIN_MAX 1 1 1'], r, g, b, v;
    for (b = 0; b < N; b++) for (g = 0; g < N; g++) for (r = 0; r < N; r++) {
      v = L2.grade(look, [r / (N - 1), g / (N - 1), b / (N - 1)], k);
      out.push(v[0].toFixed(6) + ' ' + v[1].toFixed(6) + ' ' + v[2].toFixed(6));
    }
    return out.join('\n') + '\n';
  };
  L2.lutRenderArgs = function (o) {
    return ['-y', '-hide_banner', '-ss', String(o.inSec), '-t', String(o.dur), '-i', o.src, '-vf', "lut3d='" + o.cube.replace(/'/g, "\\'") + "'",
      '-c:v', 'libx264', '-preset', 'medium', '-crf', '17', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', o.out];
  };

  // ---------- ناوچەی سەلامەت ----------
  L2.safeSpec = function (kind) {
    if (kind === 'vertical') {
      var W = 1080, H = 1920, t = Math.round(H * 0.14), bt = Math.round(H * 0.22), rt = Math.round(W * 0.13), lf = Math.round(W * 0.06);
      return { W: W, H: H, safe: { x: lf, y: t, w: W - lf - rt, h: H - t - bt },
        unsafe: [{ x: 0, y: 0, w: W, h: t, label: 'سەرەوە: ناوی پەیج' }, { x: 0, y: H - bt, w: W, h: bt, label: 'خوارەوە: کاپشن و دوگمە' }, { x: W - rt, y: t, w: rt, h: H - t - bt, label: 'ڕاست' }, { x: 0, y: t, w: lf, h: H - t - bt, label: '' }] };
    }
    if (kind === 'square') { var S = 1080, m = Math.round(S * 0.06); return { W: S, H: S, safe: { x: m, y: m, w: S - 2 * m, h: S - 2 * m }, unsafe: [] }; }
    var Wt = 1920, Ht = 1080, ax = Math.round(Wt * 0.035), ay = Math.round(Ht * 0.035), tx = Math.round(Wt * 0.05), ty = Math.round(Ht * 0.05);
    return { W: Wt, H: Ht, action: { x: ax, y: ay, w: Wt - 2 * ax, h: Ht - 2 * ay }, safe: { x: tx, y: ty, w: Wt - 2 * tx, h: Ht - 2 * ty }, unsafe: [] };
  };

  // ---------- تۆمارکردنی شاشە ----------
  L2.parseAvfDevices = function (txt) {
    var out = { video: [], audio: [] }, cur = null, lines = String(txt).split('\n'), i, m;
    for (i = 0; i < lines.length; i++) {
      if (/AVFoundation video devices/i.test(lines[i])) { cur = 'video'; continue; }
      if (/AVFoundation audio devices/i.test(lines[i])) { cur = 'audio'; continue; }
      m = /\[(\d+)\]\s+(.+?)\s*$/.exec(lines[i]);
      if (cur && m && /AVFoundation/.test(lines[i])) out[cur].push({ id: m[1], name: m[2] });
    }
    return out;
  };
  L2.recArgs = function (o) {
    var a = ['-y', '-hide_banner'];
    if (o.win) a.push('-f', 'gdigrab', '-framerate', String(o.fps || 30), '-draw_mouse', '1', '-i', 'desktop');
    else a.push('-f', 'avfoundation', '-framerate', String(o.fps || 30), '-capture_cursor', '1', '-i', o.video + ':' + (o.audio === '' || o.audio === undefined ? 'none' : o.audio));
    if (o.height) a.push('-vf', 'scale=-2:' + o.height);
    a.push('-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '18', '-pix_fmt', 'yuv420p');
    if (!o.win && o.audio !== '' && o.audio !== undefined) a.push('-c:a', 'aac', '-b:a', '192k');
    a.push(o.out);
    return a;
  };

  if (typeof window !== 'undefined') window.KZ_LIB2 = L2;
  if (typeof module !== 'undefined' && module.exports) module.exports = L2;
})();
