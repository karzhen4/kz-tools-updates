/* KZ Tools — قاڵبی شووشە: ڕەندەر بۆ ProRes 4444 (شەفاف) یان H.264 لەگەڵ بلەری کلیپی ژێرەوە */
(function () {
  'use strict';
  var KZ = window.KZ, L = window.KZ_LIB4, fs = require('fs'), path = require('path'), $ = function (s) { return document.querySelector(s); };
  var busy = false;
  var sel = $('#tp-kind'), pal = $('#tp-pal'), sty = $('#tp-style');
  L.TEXTFX.forEach(function (x) { var o = document.createElement('option'); o.value = x[0]; o.textContent = x[1]; sty.appendChild(o); });
  Object.keys(L.templates).forEach(function (k) { var o = document.createElement('option'); o.value = k; o.textContent = L.templates[k].n; sel.appendChild(o); });
  L.PALETTES.forEach(function (p) {
    var b = document.createElement('button'); b.type = 'button'; b.className = 'btn small ghost'; b.textContent = p.n; b.style.borderColor = p.a;
    b.onclick = function () { $('#tp-c1').value = p.a; $('#tp-c2').value = p.b; preview(); };
    pal.appendChild(b);
  });
  function opts() {
    var v = $('#tp-fmt').value === 'v';
    return { tpl: sel.value, W: v ? 1080 : 1920, H: v ? 1920 : 1080, vertical: v, dur: Math.max(1, parseFloat($('#tp-dur').value) || 5), fps: 30,
      style: sty.value, c1: $('#tp-c1').value, c2: $('#tp-c2').value, text: $('#tp-text').value, sub: $('#tp-sub').value, to: parseFloat($('#tp-to').value) || 0, blur: 26 };
  }
  function preview() {
    var cv = $('#tp-prev'), o = opts(); $('#tp-numrow').classList.toggle('hide', o.tpl !== 'counter'); $('#tp-stylerow').classList.toggle('hide', o.tpl !== 'textfx'); $('#tp-hint').textContent = L.templates[o.tpl].hint || '';
    cv.width = o.W; cv.height = o.H;
    var go = function () { try { L.drawFrame(cv.getContext('2d'), Math.min(o.dur * 0.5, 2.2), o, false); } catch (e) {} };
    try { document.fonts.load('700 40px "IBM Plex Sans Arabic"').then(go, go); } catch (e) { go(); }
    go();
  }
  ['#tp-style', '#tp-kind', '#tp-text', '#tp-sub', '#tp-to', '#tp-c1', '#tp-c2', '#tp-fmt', '#tp-dur'].forEach(function (s) { $(s).oninput = preview; $(s).onchange = preview; });
  $('#tp-blur').onchange = function () { };

  async function render() {
    if (!KZ.license.canUse()) { KZ.toast('کۆدی مۆڵەت پێویستە', 'bad'); return; }
    if (busy) { KZ.toast('کارێکی تر ماوە', 'bad'); return; }
    var ff = KZ.ffmpeg(); if (!ff) { KZ.toast('ffmpeg نەدۆزرایەوە. لە «ڕێکخستن» دایبەزێنە', 'bad'); return; }
    busy = true;
    try {
      var o = opts(), useBlur = $('#tp-blur').checked && L.templates[o.tpl].blur;
      var s = await KZ.jsx('getSelection'), src = null, ss = 0;
      if (useBlur) {
        var c = s.ok && (s.clips || []).filter(function (x) { return x.path && x.kind === 'video'; })[0];
        if (!c) { KZ.toast('بۆ بلەر، کلیپێکی ڤیدیۆ هەڵبژێرە', 'bad'); busy = false; return; }
        src = c.path; ss = c.inPoint + Math.max(0, Math.min(s.playhead - c.start, (c.end - c.start) - 0.1));
      }
      var dir = KZ.tmp('tpl_' + Date.now()); fs.mkdirSync(dir);
      try { await document.fonts.load('700 40px "IBM Plex Sans Arabic"'); } catch (e) {}
      var cv = document.createElement('canvas'); cv.width = o.W; cv.height = o.H; var cx = cv.getContext('2d'), n = Math.max(2, Math.round(o.dur * o.fps)), i;
      function save(name, mask) { L.drawFrame(cx, 0, o, mask); }
      for (i = 0; i < n; i++) {
        L.drawFrame(cx, i / o.fps, o, false);
        fs.writeFileSync(path.join(dir, 'g_' + ('00000' + i).slice(-5) + '.png'), Buffer.from(cv.toDataURL('image/png').split(',')[1], 'base64'));
        if (useBlur) { L.drawFrame(cx, i / o.fps, o, true); fs.writeFileSync(path.join(dir, 'm_' + ('00000' + i).slice(-5) + '.png'), Buffer.from(cv.toDataURL('image/png').split(',')[1], 'base64')); }
        if (i % 3 === 0) { KZ.progress(i / n * 80, 'ڕەندەر ' + Math.round(i / n * 100) + '%'); await new Promise(function (r) { setTimeout(r, 0); }); }
      }
      KZ.progress(85, useBlur ? 'بلەر و تێکەڵکردن...' : 'کۆدکردن...');
      var out = path.join(KZ.workDir(), 'kz_tpl_' + o.tpl + '_' + Date.now() + (useBlur ? '.mp4' : '.mov'));
      var args = useBlur ? L.blurArgs(o, src, ss, path.join(dir, 'g_%05d.png'), path.join(dir, 'm_%05d.png'), out) : L.alphaArgs(o, path.join(dir, 'g_%05d.png'), out);
      var r = await KZ.exec(ff, args);
      await KZ.exec(KZ.isWin ? 'cmd' : 'rm', KZ.isWin ? ['/c', 'rmdir', '/s', '/q', dir] : ['-rf', dir]);
      if (r.code !== 0) throw new Error('ffmpeg: ' + (r.err || '').slice(-200));
      var p = await KZ.jsx('placeVideo', { path: out, at: s.ok ? s.playhead : 0, track: Math.max(0, (parseInt($('#tp-vt').value, 10) || 3) - 1) });
      if (!p.ok) { KZ.toast('دروست بوو بەڵام دانان نەکرا: ' + p.error, 'bad'); KZ.log(out); } else KZ.toast('قاڵب دانرا');
    } catch (e) { KZ.toast('هەڵە: ' + (e && e.message || e), 'bad'); KZ.log('هەڵە: ' + (e && e.message || e)); }
    busy = false; KZ.progress(-1);
  }
  $('#tp-go').onclick = render;
  preview();
})();
